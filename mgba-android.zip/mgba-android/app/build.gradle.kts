plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mgba.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mgba.android"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            // arm64-v8a covers every Android phone made since ~2015.
            // x86_64 is only needed for PC emulators — drop it to halve native lib size.
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments(
                    "-DLIBMGBA_ONLY=ON",
                    "-DM_CORE_GBA=ON",
                    "-DM_CORE_GB=ON",
                    "-DBUILD_STATIC=ON",
                    "-DBUILD_SHARED=OFF",
                    "-DDISABLE_FRONTENDS=ON",
                    "-DDISABLE_DEPS=ON"
                )
                // -Os  = optimise for size (smaller than -O2 for this workload)
                // -ffunction-sections / -fdata-sections + --gc-sections at link time
                //   dead-strips any mGBA code paths we never call
                // -fvisibility=hidden hides internal symbols so the linker can strip more
                cFlags  ("-Os -ffunction-sections -fdata-sections -fvisibility=hidden")
                cppFlags("-Os -ffunction-sections -fdata-sections -fvisibility=hidden -std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled  = false   // R8 for Kotlin; native is stripped separately
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    // Strip debug symbols from .so files in every build type.
    // This is the single biggest APK-size win — debug symbols can be 3–5× the code size.
    packaging {
        jniLibs {
            // 'true' = keep compressed .so in APK (smaller download, tiny perf cost on first run)
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
