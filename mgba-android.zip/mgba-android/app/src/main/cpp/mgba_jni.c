/*
 * mgba_jni.c — JNI bridge between the mGBA core and Android/Kotlin.
 *
 * Kotlin API (EmulatorEngine.kt):
 *   nativeLoadROM(path: String): Boolean
 *   nativeRunFrame(bitmap: Bitmap)
 *   nativeSetKeys(keys: Int)
 *   nativeGetWidth(): Int
 *   nativeGetHeight(): Int
 *   nativeDestroy()
 *
 * GBA key bitmask (matches enum GBAKey in mgba/internal/gba/input.h):
 *   A=0x001  B=0x002  SELECT=0x004  START=0x008
 *   RIGHT=0x010  LEFT=0x020  UP=0x040  DOWN=0x080
 *   R=0x100  L=0x200
 */

#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* mGBA public API */
#include <mgba/core/core.h>     /* mCoreFind, mCoreLoadFile, struct mCore */
#include <mgba/core/log.h>      /* mLogSetDefaultLogger */
#include <mgba-util/image.h>    /* mColor */

#define LOG_TAG "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── State ─────────────────────────────────────────────────────────────────── */

static struct mCore *g_core   = NULL;
static mColor       *g_fb     = NULL;   /* native framebuffer (mGBA format)   */
static int           g_width  = 240;
static int           g_height = 160;

/* ── Logger ─────────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)level; (void)category;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);
    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Helpers ────────────────────────────────────────────────────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── JNI functions ──────────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    destroy_core();
    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);

    /* Auto-detect ROM type (GBA / GB / GBC) and create the matching core */
    struct mCore *core = mCoreFind(path);
    if (!core) {
        LOGE("mCoreFind failed — unsupported ROM: %s", path);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* Initialise the core (allocates internal structures) */
    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* Ask the core for its native screen size */
    unsigned w = 240, h = 160;
    core->baseVideoSize(core, &w, &h);
    g_width  = (int)w;
    g_height = (int)h;

    /* Allocate our framebuffer and hand it to the core */
    g_fb = (mColor *)malloc((size_t)g_width * (size_t)g_height * sizeof(mColor));
    if (!g_fb) {
        LOGE("framebuffer malloc failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    memset(g_fb, 0, (size_t)g_width * (size_t)g_height * sizeof(mColor));
    core->setVideoBuffer(core, g_fb, (size_t)g_width);

    /* Load the ROM file */
    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed for: %s", path);
        free(g_fb); g_fb = NULL;
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* Reset into a known-good state */
    core->reset(core);
    g_core = core;

    LOGI("ROM loaded OK — %dx%d", g_width, g_height);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    if (!g_core || !g_fb) return;

    /* Advance one emulated frame */
    g_core->runFrame(g_core);

    /* ── Copy framebuffer into the Android Bitmap ──────────────────────────
     *
     * mGBA native format (no COLOR_16_BIT): mColor = uint32_t = 0x00BBGGRR
     *   M_COLOR_RED   = 0x000000FF  (red  in byte 0)
     *   M_COLOR_BLUE  = 0x00FF0000  (blue in byte 2)
     *
     * Android ARGB_8888              = 0xFFRRGGBB
     *
     * Trick: bswap32(0x00BBGGRR) = 0xRRGGBB00
     *        >> 8                = 0x00RRGGBB
     *        | 0xFF000000        = 0xFFRRGGBB  ✓
     */
    AndroidBitmapInfo info;
    void *pixels = NULL;

    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        LOGW("AndroidBitmap_getInfo failed");
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        LOGW("AndroidBitmap_lockPixels failed");
        return;
    }

    const mColor *src = g_fb;
    uint32_t     *dst = (uint32_t *)pixels;
    int n = g_width * g_height;

    for (int i = 0; i < n; i++) {
        uint32_t p = src[i];                       /* 0x00BBGGRR */
        dst[i] = (__builtin_bswap32(p) >> 8)      /* 0x00RRGGBB */
               | 0xFF000000u;                      /* 0xFFRRGGBB */
    }

    AndroidBitmap_unlockPixels(env, bitmap);
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    if (g_core) {
        g_core->setKeys(g_core, (uint32_t)keys);
    }
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(
        JNIEnv *env, jobject thiz)
{
    return (jint)g_width;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(
        JNIEnv *env, jobject thiz)
{
    return (jint)g_height;
}

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(
        JNIEnv *env, jobject thiz)
{
    destroy_core();
    LOGI("mGBA core destroyed");
}
