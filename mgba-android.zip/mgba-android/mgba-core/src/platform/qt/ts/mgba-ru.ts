<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU" sourcelanguage="en_US">
<context>
    <name>LibraryTree</name>
    <message>
        <location filename="../library/LibraryModel.cpp" line="427"/>
        <source>Name</source>
        <translation>Название</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="429"/>
        <source>Location</source>
        <translation>Расположение</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="431"/>
        <source>Platform</source>
        <translation>Платформа</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="433"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../library/LibraryModel.cpp" line="435"/>
        <source>CRC32</source>
        <translation>CRC32</translation>
    </message>
</context>
<context>
    <name>QGBA</name>
    <message>
        <location filename="../utils.cpp" line="109"/>
        <source>Game Boy Advance ROMs (%1)</source>
        <translation>РОМы Game Boy Advance (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="135"/>
        <source>Game Boy ROMs (%1)</source>
        <translation>РОМы Game Boy (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="140"/>
        <source>All ROMs (%1)</source>
        <translation>Все РОМы (%1)</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="142"/>
        <source>%1 Video Logs (*.mvl)</source>
        <translation>Журналы видео %1 (*.mvl)</translation>
    </message>
</context>
<context>
    <name>QGBA::AboutScreen</name>
    <message>
        <location filename="../AboutScreen.ui" line="14"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="23"/>
        <source>&lt;a href=&quot;http://mgba.io/&quot;&gt;Website&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Forums / Support&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Donate&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Source&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://mgba.io/&quot;&gt;Сайт&lt;/a&gt; • &lt;a href=&quot;https://forums.mgba.io/&quot;&gt;Форум / Поддержка&lt;/a&gt; • &lt;a href=&quot;https://patreon.com/mgba&quot;&gt;Пожертвовать&lt;/a&gt; • &lt;a href=&quot;https://github.com/mgba-emu/mgba/tree/{gitBranch}&quot;&gt;Исходный код&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="41"/>
        <source>Branch: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revision: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</source>
        <translation>Ветка: &lt;tt&gt;{gitBranch}&lt;/tt&gt;&lt;br/&gt;Revision: &lt;tt&gt;{gitCommit}&lt;/tt&gt;</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="68"/>
        <source>{projectName} would like to thank the following patrons from Patreon:</source>
        <translation>{projectName} благодарит своих подписчиков с Patreon:</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="86"/>
        <source>© 2013 – {year} Jeffrey Pfau, licensed under the Mozilla Public License, version 2.0
Game Boy Advance is a registered trademark of Nintendo Co., Ltd.</source>
        <translation>© 2013 – {year} Jeffrey Pfau, под лицензией Mozilla Public License, version 2.0
Game Boy Advance - зарегистрированная торговая марка Nintendo Co., Ltd.</translation>
    </message>
    <message>
        <location filename="../AboutScreen.ui" line="177"/>
        <source>{projectName} is an open-source Game Boy Advance emulator</source>
        <translation>{projectName} - эмулятор Game Boy Advance с открытым исходным кодом</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdatePrompt</name>
    <message>
        <location filename="../ApplicationUpdatePrompt.ui" line="14"/>
        <source>An update is available</source>
        <translation>Доступно обновление</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="26"/>
        <source>An update to %1 is available.
</source>
        <translation>Доступно обновление до %1.
</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="38"/>
        <source>
Do you want to download and install it now? You will need to restart the emulator when the download is complete.</source>
        <translation>
Вы хотите скачать и установить сейчас? Вам надо будет перезагрузить эмулятор когда загрузка закончится.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="41"/>
        <source>
Auto-update is not available on this platform. If you wish to update you will need to do it manually.</source>
        <translation>
Автообновление не доступно на этой платформе. Если вы хотите обновить эмулятор вам нужно сделать это вручную.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="45"/>
        <source>Current version: %1
New version: %2
Download size: %3</source>
        <translation>Текущая версия: %1
Новая версия: %2
Размер файла: %3</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="63"/>
        <source>Downloading update...</source>
        <translation>Загрузка обновления...</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="79"/>
        <source>Downloading failed. Please update manually.</source>
        <translation>Загрузка не удалась. Пожалуйста, загрузите обновление вручную.</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdatePrompt.cpp" line="82"/>
        <source>Downloading done. Press OK to restart %1 and install the update.</source>
        <translation>Загрузка завершена. Нажмите OK для перезапуска и установки обновления.</translation>
    </message>
</context>
<context>
    <name>QGBA::ApplicationUpdater</name>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="90"/>
        <source>Stable</source>
        <translation>Стабильная</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="93"/>
        <source>Development</source>
        <translation>В разработке</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="95"/>
        <source>Unknown</source>
        <translation>Неизвестно</translation>
    </message>
    <message>
        <location filename="../ApplicationUpdater.cpp" line="239"/>
        <source>(None)</source>
        <translation>(Нет)</translation>
    </message>
</context>
<context>
    <name>QGBA::ArchiveInspector</name>
    <message>
        <location filename="../ArchiveInspector.ui" line="14"/>
        <source>Open in archive...</source>
        <translation>Открыть в архиве...</translation>
    </message>
    <message>
        <location filename="../ArchiveInspector.ui" line="20"/>
        <source>Loading...</source>
        <translation>Загрузка...</translation>
    </message>
</context>
<context>
    <name>QGBA::AssetTile</name>
    <message>
        <location filename="../AssetTile.ui" line="41"/>
        <source>Tile #</source>
        <translation>Тайл #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="65"/>
        <source>Palette #</source>
        <translation>Палитра #</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="89"/>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="138"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="145"/>
        <source>Green</source>
        <translation>Зеленый</translation>
    </message>
    <message>
        <location filename="../AssetTile.ui" line="152"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../AssetTile.cpp" line="143"/>
        <location filename="../AssetTile.cpp" line="144"/>
        <location filename="../AssetTile.cpp" line="145"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioDevice</name>
    <message>
        <location filename="../AudioDevice.cpp" line="35"/>
        <source>Can&apos;t set format of context-less audio device</source>
        <translation>Невозможно установить формат для аудиоустройства без контекста</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="56"/>
        <source>Audio device is missing its core</source>
        <translation>Отсутствует ядро аудиоустройства</translation>
    </message>
    <message>
        <location filename="../AudioDevice.cpp" line="84"/>
        <source>Writing data to read-only audio device</source>
        <translation>Запись данных в аудиоустройство только для чтения</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorQt</name>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="56"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Невозможно запустить аудиопроцессор без входных данных</translation>
    </message>
    <message>
        <location filename="../AudioProcessorQt.cpp" line="81"/>
        <source>Audio outputting to %1</source>
        <translation>Звук выводится на %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AudioProcessorSDL</name>
    <message>
        <location filename="../AudioProcessorSDL.cpp" line="34"/>
        <source>Can&apos;t start an audio processor without input</source>
        <translation>Невозможно запустить аудиопроцессор без входных данных</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptModel</name>
    <message>
        <location filename="../scripting/AutorunScriptModel.cpp" line="31"/>
        <source>Could not load autorun script settings: unknown script info format %1</source>
        <translation>Не удалось загрузить настройки скрипта автозапуска: неизвестный формат информации скрипта %1</translation>
    </message>
</context>
<context>
    <name>QGBA::AutorunScriptView</name>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="14"/>
        <source>Autorun scripts</source>
        <translation>Автоматически запускать скрипты</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="20"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="30"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="53"/>
        <source>Move up</source>
        <translation>Подвинуть вверх</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="63"/>
        <source>Move down</source>
        <translation>Подвинуть вниз</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.ui" line="73"/>
        <source>Run scripts when starting a game</source>
        <translation>Запустить скрипты, когда загружается игра</translation>
    </message>
    <message>
        <location filename="../scripting/AutorunScriptView.cpp" line="28"/>
        <source>Select a script</source>
        <translation>Выбрать скрипт</translation>
    </message>
</context>
<context>
    <name>QGBA::BattleChipView</name>
    <message>
        <location filename="../BattleChipView.ui" line="14"/>
        <source>BattleChip Gate</source>
        <translation>Чип BattleChip Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="67"/>
        <source>Chip name</source>
        <translation>Имя чипа</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="76"/>
        <source>Insert</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="87"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="94"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="114"/>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="121"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="138"/>
        <source>Gate type</source>
        <translation>Тип Gate</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="180"/>
        <source>Inserted</source>
        <translation>Вставлен</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="194"/>
        <source>Chip ID</source>
        <translation>ID чипа</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="207"/>
        <source>Update Chip data</source>
        <translation>Обновление данных чипа</translation>
    </message>
    <message>
        <location filename="../BattleChipView.ui" line="219"/>
        <source>Show advanced</source>
        <translation>Расширенные настройки</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="115"/>
        <source>BattleChip data missing</source>
        <translation>Отсутствуют данные BattleChip</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="116"/>
        <source>BattleChip data is missing. BattleChip Gates will still work, but some graphics will be missing. Would you like to download the data now?</source>
        <translation>Отсутствуют данные BattleChip. BattleChip Gates будут работать, но часть графики будет отсутствовать. Скачать данные сейчас?</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="182"/>
        <location filename="../BattleChipView.cpp" line="201"/>
        <source>Select deck file</source>
        <translation>Выберите файл колоды</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="213"/>
        <source>Incompatible deck</source>
        <translation>Колода несовместима</translation>
    </message>
    <message>
        <location filename="../BattleChipView.cpp" line="214"/>
        <source>The selected deck is not compatible with this Chip Gate</source>
        <translation>Выбранная колода несовместима с этим Chip Gate</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsModel</name>
    <message>
        <location filename="../CheatsModel.cpp" line="53"/>
        <source>(untitled)</source>
        <translation>(без имени)</translation>
    </message>
    <message>
        <location filename="../CheatsModel.cpp" line="211"/>
        <source>Failed to open cheats file: %1</source>
        <translation>Не удалось открыть файл с чит-кодами: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CheatsView</name>
    <message>
        <location filename="../CheatsView.ui" line="14"/>
        <source>Cheats</source>
        <translation>Читы</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="39"/>
        <source>Add New Code</source>
        <translation>Добавить новый код</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="60"/>
        <source>Remove</source>
        <translation>Убрать</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="93"/>
        <source>Add Lines</source>
        <translation>Добавить линии</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="100"/>
        <source>Code type</source>
        <translation>Тип кода</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="53"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="46"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../CheatsView.ui" line="86"/>
        <source>Enter codes here...</source>
        <translation>Введите свои читкоды сюда...</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="49"/>
        <location filename="../CheatsView.cpp" line="57"/>
        <source>Autodetect (recommended)</source>
        <translation>Автоопределение (рекомендовано)</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="87"/>
        <location filename="../CheatsView.cpp" line="94"/>
        <source>Select cheats file</source>
        <translation>Выберите файл с чит-кодами</translation>
    </message>
    <message>
        <location filename="../CheatsView.cpp" line="186"/>
        <source>Some cheats could not be added. Please ensure they&apos;re formatted correctly and/or try other cheat types.</source>
        <translation>Некоторые читы не были добавлены. Убедитесь, что они правильного формата, и/или измените тип чита.</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreController</name>
    <message>
        <location filename="../CoreController.cpp" line="104"/>
        <source>Reset r%1-%2 %3</source>
        <translation>Сброс r%1-%2 %3</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="552"/>
        <location filename="../CoreController.cpp" line="569"/>
        <source>Rewinding not currently enabled</source>
        <translation>Обратная перемотка выключена</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="608"/>
        <source>Reset the game?</source>
        <translation>Перезагрузить игру?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="609"/>
        <source>Most games will require a reset to load the new save. Do you want to reset now?</source>
        <translation>Большинству игр нужна перезагрузка, чтобы загрузить новое сохранение. Перезагрузить сейчас?</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="827"/>
        <source>Failed to open save file: %1</source>
        <translation>Не удалось открыть файл сохранения: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="885"/>
        <source>Failed to open game file: %1</source>
        <translation>Не удалось открыть файл игры: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="915"/>
        <source>Can&apos;t yank pack in unexpected platform!</source>
        <translation>Невозможно пнуть картридж на неожиданной платформе!</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1030"/>
        <source>Failed to open snapshot file for reading: %1</source>
        <translation>Не удалось открыть файл изображения для считывания: %1</translation>
    </message>
    <message>
        <location filename="../CoreController.cpp" line="1047"/>
        <source>Failed to open snapshot file for writing: %1</source>
        <translation>Не удалось открыть файл изображения для записи: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::CoreManager</name>
    <message>
        <location filename="../CoreManager.cpp" line="52"/>
        <source>Failed to open game file: %1</source>
        <translation>Не удалось открыть файл игры: %1</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="77"/>
        <source>The ROM appears to be loaded from a temporary directory. This will likely lead to data loss (e.g. saves, screenshots, etc.) if you continue. Please put the ROM in a more suitable location and then re-open it. If you are loading the ROM from an archive, please extract the archive first.</source>
        <translation>Похоже ROM загружен из временной папки. Если вы продолжите, это скорее всего приведет к потере данных (например сохранений, скриншотов и т.д). Пожалуйста переместите ROM в более подходящее расположение и переоткройте его. Если вы загружаете ROM из архива, пожалуйста сначала извлеките его.</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="95"/>
        <source>Could not load game. Are you sure it&apos;s in the correct format?</source>
        <translation>Не удалось загрузить игру. Вы уверены, что она в правильном формате?</translation>
    </message>
    <message>
        <location filename="../CoreManager.cpp" line="122"/>
        <source>Failed to open save file; in-game saves cannot be updated. Please ensure the save directory is writable without additional privileges (e.g. UAC on Windows).</source>
        <translation>Не удалось открыть файл с сохранениями; внутриигровые сохранения не могут быть обновлены. Убедитесь, что директория с сохранениями доступна на запись без повышения привилегий (например, UAC на Windows).</translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsole</name>
    <message>
        <location filename="../DebuggerConsole.ui" line="14"/>
        <source>Debugger</source>
        <translation>Дебаггер</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="20"/>
        <source>Enter command (try `help` for more info)</source>
        <translation>Введите команду (`help` чтобы узнать больше)</translation>
    </message>
    <message>
        <location filename="../DebuggerConsole.ui" line="27"/>
        <source>Break</source>
        <translation>Прервать</translation>
    </message>
</context>
<context>
    <name>QGBA::DebuggerConsoleController</name>
    <message>
        <location filename="../DebuggerConsoleController.cpp" line="183"/>
        <source>Could not open CLI history for writing</source>
        <translation>Не удалось открыть историю CLI на запись</translation>
    </message>
</context>
<context>
    <name>QGBA::DisplayGL</name>
    <message>
        <location filename="../DisplayGL.cpp" line="314"/>
        <source>Failed to create an OpenGL 3 context, trying old-style...</source>
        <translation>Не удалось создать контекст OpenGL 3, попытка использовать старый стиль...</translation>
    </message>
</context>
<context>
    <name>QGBA::DolphinConnector</name>
    <message>
        <location filename="../DolphinConnector.ui" line="14"/>
        <source>Connect to Dolphin</source>
        <translation>Соединение с Dolphin</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="23"/>
        <source>Local computer</source>
        <translation>Локальный компьютер</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="36"/>
        <source>IP address</source>
        <translation>IP-адрес</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="55"/>
        <source>Connect</source>
        <translation>Подключиться</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="68"/>
        <source>Disconnect</source>
        <translation>Отключиться</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="78"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.ui" line="90"/>
        <source>Reset on connect</source>
        <translation>Сброс при соединении</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="57"/>
        <source>Couldn&apos;t Connect</source>
        <translation>Ошибка Соединения</translation>
    </message>
    <message>
        <location filename="../DolphinConnector.cpp" line="58"/>
        <source>Could not connect to Dolphin.</source>
        <translation>Не удалось соединиться с Dolphin.</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator</name>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="83"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator.cpp" line="85"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGenerator3DS</name>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="29"/>
        <source>Icon</source>
        <translation>Иконка</translation>
    </message>
    <message>
        <location filename="../ForwarderGenerator3DS.cpp" line="30"/>
        <source>Banner</source>
        <translation>Баннер</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderGeneratorVita</name>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="25"/>
        <source>Bubble</source>
        <translation>Пузырь</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="26"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../ForwarderGeneratorVita.cpp" line="27"/>
        <source>Startup</source>
        <translation>Автозапуск</translation>
    </message>
</context>
<context>
    <name>QGBA::ForwarderView</name>
    <message>
        <location filename="../ForwarderView.ui" line="14"/>
        <source>Create forwarder</source>
        <translation>Создать перенаправитель</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="20"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="26"/>
        <source>ROM file:</source>
        <translation>РОМ файл:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="36"/>
        <location filename="../ForwarderView.ui" line="53"/>
        <location filename="../ForwarderView.ui" line="112"/>
        <source>Browse</source>
        <translation>Обзор</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="43"/>
        <source>Output filename:</source>
        <translation>Имя выходного файла:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="60"/>
        <source>Forwarder base:</source>
        <translation>База перенаправителя:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="74"/>
        <source>Latest stable version</source>
        <translation>Последняя стабильная версия</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="79"/>
        <source>Latest development build</source>
        <translation>Последняя разрабатываемая сборка</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="84"/>
        <source>Specific file</source>
        <translation>Конкретный файл</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="95"/>
        <source>Base file:</source>
        <translation>Базовый файл:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="135"/>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="141"/>
        <source>3DS</source>
        <translation>3DS</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="151"/>
        <source>Vita</source>
        <translation>Vita</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="174"/>
        <source>Presentation</source>
        <translation>Представление</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="182"/>
        <source>Title:</source>
        <translation>Заголовок:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="195"/>
        <source>Images:</source>
        <translation>Изображения:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="215"/>
        <source>Use default image</source>
        <translation>Использовать изображение по умолчанию</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="328"/>
        <source>Preferred size:</source>
        <translation>Предпочтительный размер:</translation>
    </message>
    <message>
        <location filename="../ForwarderView.ui" line="395"/>
        <source>Select image file</source>
        <translation>Выбрать файл изображения</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="22"/>
        <source>Select ROM file</source>
        <translation>Выбрать РОМ файл</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="23"/>
        <source>Select output filename</source>
        <translation>Выбрать имя выходного файла</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="24"/>
        <source>Select base file</source>
        <translation>Выбрать базовый файл</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="36"/>
        <source>Build finished</source>
        <translation>Сборка завершена</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="37"/>
        <source>Forwarder finished building</source>
        <translation>Перенаправитель закончил сборку</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="44"/>
        <source>Build failed</source>
        <translation>Неудачная сборка</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="45"/>
        <source>Failed to build forwarder</source>
        <translation>Не удалось собрать перенаправитель</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="176"/>
        <source>%1 installable package (*.%2)</source>
        <translation>%1 устанавливаемый пакет (*.%2)</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="192"/>
        <source>Select an image</source>
        <translation>Выбрать изображение</translation>
    </message>
    <message>
        <location filename="../ForwarderView.cpp" line="192"/>
        <source>Image files (*.png *.jpg *.bmp)</source>
        <translation>Файлы изображения (*.png *.jpg *.bmp)</translation>
    </message>
</context>
<context>
    <name>QGBA::FrameView</name>
    <message>
        <location filename="../FrameView.ui" line="14"/>
        <source>Inspect frame</source>
        <translation>Изучить фрейм</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="41"/>
        <source>Magnification</source>
        <translation>Увеличить</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="50"/>
        <source>Freeze frame</source>
        <translation>Зафиксировать фрейм</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="84"/>
        <source>Backdrop color</source>
        <translation>Цвет фона</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="132"/>
        <source>Disable scanline effects</source>
        <translation>Выключить эффект scanline</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="145"/>
        <source>Export</source>
        <translation>Экспортировать</translation>
    </message>
    <message>
        <location filename="../FrameView.ui" line="152"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="591"/>
        <source>Export frame</source>
        <translation>Экспорт кадра</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="592"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="622"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="624"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="627"/>
        <source>Window</source>
        <translation>Окно</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="630"/>
        <source>Objwin</source>
        <translation>Objwin</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="635"/>
        <source>Sprite</source>
        <translation>Спрайт</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="638"/>
        <source>Backdrop</source>
        <translation>Подложка</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="641"/>
        <source>Frame</source>
        <translation>Кадр</translation>
    </message>
    <message>
        <location filename="../FrameView.cpp" line="647"/>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAApp</name>
    <message>
        <location filename="../GBAApp.cpp" line="82"/>
        <source>Enable Discord Rich Presence</source>
        <translation>Вкл. расширенный статус в Discord</translation>
    </message>
</context>
<context>
    <name>QGBA::GBAKeyEditor</name>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="69"/>
        <source>Clear Button</source>
        <translation>Сброс кнопки</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="81"/>
        <source>Clear Analog</source>
        <translation>Сброс аналога</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="92"/>
        <source>Refresh</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../GBAKeyEditor.cpp" line="102"/>
        <source>Set all</source>
        <translation>Назначить все</translation>
    </message>
</context>
<context>
    <name>QGBA::GDBWindow</name>
    <message>
        <location filename="../GDBWindow.cpp" line="31"/>
        <source>Server settings</source>
        <translation>Настройки сервера</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="37"/>
        <source>Local port</source>
        <translation>Локальный порт</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="39"/>
        <source>Bind address</source>
        <translation>Привязка адреса</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="52"/>
        <source>Write watchpoints behavior</source>
        <translation>Поведение контрольных точек записи</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="63"/>
        <source>Standard GDB</source>
        <translation>Стандарт (GDB)</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="68"/>
        <source>Internal change detection</source>
        <translation>Обнаружение внутренних изменений</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="72"/>
        <source>Break on all writes</source>
        <translation>Прерывать при любой записи</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="82"/>
        <source>Break</source>
        <translation>Прервать</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="124"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="137"/>
        <source>Start</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="145"/>
        <source>Crash</source>
        <translation>Сбой</translation>
    </message>
    <message>
        <location filename="../GDBWindow.cpp" line="145"/>
        <source>Could not start GDB server</source>
        <translation>Не удалось запустить GDB-сервер</translation>
    </message>
</context>
<context>
    <name>QGBA::GIFView</name>
    <message>
        <location filename="../GIFView.ui" line="145"/>
        <source>Frameskip</source>
        <translation>Пропуск кадров</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="51"/>
        <source>Start</source>
        <translation>Начать</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="14"/>
        <source>Record GIF/WebP/APNG</source>
        <translation>Записать GIF/WebP/APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="30"/>
        <source>Loop</source>
        <translation>Зациклить</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="67"/>
        <source>Stop</source>
        <translation>Остановить</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="93"/>
        <source>Select File</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="112"/>
        <source>APNG</source>
        <translation>APNG</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="122"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../GIFView.ui" line="135"/>
        <source>WebP</source>
        <translation>WebP</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="63"/>
        <source>Failed to open output file: %1</source>
        <translation>Не удалось открыть выходной файл: %1</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="90"/>
        <source>Select output file</source>
        <translation>Выбор выходного файла</translation>
    </message>
    <message>
        <location filename="../GIFView.cpp" line="90"/>
        <source>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</source>
        <translation>Graphics Interchange Format (*.gif);;WebP ( *.webp);;Animated Portable Network Graphics (*.png *.apng)</translation>
    </message>
</context>
<context>
    <name>QGBA::GameBoy</name>
    <message>
        <location filename="../GameBoy.cpp" line="62"/>
        <location filename="../GameBoy.cpp" line="81"/>
        <source>Autodetect</source>
        <translation>Автоопределение</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="63"/>
        <source>Game Boy (DMG)</source>
        <translation>Game Boy (DMG)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="64"/>
        <source>Game Boy Pocket (MGB)</source>
        <translation>Game Boy Pocket (MGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="65"/>
        <source>Super Game Boy (SGB)</source>
        <translation>Super Game Boy (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="66"/>
        <source>Super Game Boy 2 (SGB)</source>
        <translation>Super Game Boy 2 (SGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="67"/>
        <source>Game Boy Color (CGB)</source>
        <translation>Game Boy Color (CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="68"/>
        <source>Game Boy Advance (AGB)</source>
        <translation>Game Boy Advance (AGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="69"/>
        <source>Super Game Boy Color (SGB + CGB)</source>
        <translation>Super Game Boy Color (SGB + CGB)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="82"/>
        <source>ROM Only</source>
        <translation>Только ROM</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="86"/>
        <source>%1 + RTC</source>
        <translation>%1 + RTC</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="88"/>
        <source>%1 + Rumble</source>
        <translation>%1 + Вибрация</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="90"/>
        <source>%1 (Tilt)</source>
        <translation>%1 (Наклон)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="98"/>
        <source>%1 (old 1)</source>
        <translation>%1 (старое 1)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="99"/>
        <source>%1 (old 2)</source>
        <translation>%1 (старое 2)</translation>
    </message>
    <message>
        <location filename="../GameBoy.cpp" line="100"/>
        <source>%1 (new)</source>
        <translation>%1 (новое)</translation>
    </message>
</context>
<context>
    <name>QGBA::IOViewer</name>
    <message>
        <location filename="../IOViewer.ui" line="14"/>
        <source>I/O Viewer</source>
        <translation>Просмотр I/O</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="26"/>
        <source>0x0000</source>
        <translation>0x0000</translation>
    </message>
    <message>
        <location filename="../IOViewer.ui" line="367"/>
        <location filename="../IOViewer.cpp" line="870"/>
        <location filename="../IOViewer.cpp" line="883"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="39"/>
        <source>Background mode</source>
        <translation>Режим фона</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="40"/>
        <source>Mode 0: 4 tile layers</source>
        <translation>Режим 0: 4 тайловых слоя</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="41"/>
        <source>Mode 1: 2 tile layers + 1 rotated/scaled tile layer</source>
        <translation>Режим 1: 2 тайловых слоя + 1 тайл. слой с вращением/масштабированием</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="42"/>
        <source>Mode 2: 2 rotated/scaled tile layers</source>
        <translation>Режим 2: 2 тайловых слоя с вращением/масштабированием</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="43"/>
        <source>Mode 3: Full 15-bit bitmap</source>
        <translation>Режим 3: Полная 15-битная битовая карта</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="44"/>
        <source>Mode 4: Full 8-bit bitmap</source>
        <translation>Режим 4: Полная 8-битная битовая карта</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="45"/>
        <source>Mode 5: Small 15-bit bitmap</source>
        <translation>Режим 5: Малая 15-битная битовая карта</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="49"/>
        <source>CGB Mode</source>
        <translation>Режим CGB</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="50"/>
        <source>Frame select</source>
        <translation>Выбор кадра</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="51"/>
        <source>Unlocked HBlank</source>
        <translation>Разблокированный HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="52"/>
        <source>Linear OBJ tile mapping</source>
        <translation>Линейная отрисовка OBJ тайлов</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="53"/>
        <source>Force blank screen</source>
        <translation>Принудительная очистка экрана</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="54"/>
        <source>Enable background 0</source>
        <translation>Вкл. фон 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="55"/>
        <source>Enable background 1</source>
        <translation>Вкл. фон 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="56"/>
        <source>Enable background 2</source>
        <translation>Вкл. фон 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="57"/>
        <source>Enable background 3</source>
        <translation>Вкл. фон 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="58"/>
        <source>Enable OBJ</source>
        <translation>Вкл. OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="59"/>
        <source>Enable Window 0</source>
        <translation>Вкл. Окно 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="60"/>
        <source>Enable Window 1</source>
        <translation>Вкл. Окно 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="61"/>
        <source>Enable OBJ Window</source>
        <translation>Вкл. Окно OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="65"/>
        <source>Swap green components</source>
        <translation>Поменять местами зеленые компоненты</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="69"/>
        <source>Currently in VBlank</source>
        <translation>Сейчас в VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="70"/>
        <source>Currently in HBlank</source>
        <translation>Сейчас в HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="71"/>
        <source>Currently in VCounter</source>
        <translation>Сейчас в VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="72"/>
        <source>Enable VBlank IRQ generation</source>
        <translation>Включить генерацию VBlank IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="73"/>
        <source>Enable HBlank IRQ generation</source>
        <translation>Включить генерацию HBlank IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="74"/>
        <source>Enable VCounter IRQ generation</source>
        <translation>Включить генерацию VCounter IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="75"/>
        <source>VCounter scanline</source>
        <translation>Строка VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="79"/>
        <source>Current scanline</source>
        <translation>Текущая строка</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="83"/>
        <location filename="../IOViewer.cpp" line="92"/>
        <location filename="../IOViewer.cpp" line="101"/>
        <location filename="../IOViewer.cpp" line="111"/>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="84"/>
        <location filename="../IOViewer.cpp" line="93"/>
        <location filename="../IOViewer.cpp" line="102"/>
        <location filename="../IOViewer.cpp" line="112"/>
        <source>Tile data base (* 16kB)</source>
        <translation>Базовый адрес данных тайлов (* 16кБ)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="85"/>
        <location filename="../IOViewer.cpp" line="94"/>
        <location filename="../IOViewer.cpp" line="103"/>
        <location filename="../IOViewer.cpp" line="113"/>
        <source>Enable mosaic</source>
        <translation>Включить мозаику</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="86"/>
        <location filename="../IOViewer.cpp" line="95"/>
        <location filename="../IOViewer.cpp" line="104"/>
        <location filename="../IOViewer.cpp" line="114"/>
        <source>Enable 256-color</source>
        <translation>Включить 256 цветов</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="87"/>
        <location filename="../IOViewer.cpp" line="96"/>
        <location filename="../IOViewer.cpp" line="105"/>
        <location filename="../IOViewer.cpp" line="115"/>
        <source>Tile map base (* 2kB)</source>
        <translation>Базовый адрес карты тайлов (* 2кБ)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="88"/>
        <location filename="../IOViewer.cpp" line="97"/>
        <location filename="../IOViewer.cpp" line="107"/>
        <location filename="../IOViewer.cpp" line="117"/>
        <source>Background dimensions</source>
        <translation>Размер фона</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="106"/>
        <location filename="../IOViewer.cpp" line="116"/>
        <source>Overflow wraps</source>
        <translation>Переносы при переполнении</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="121"/>
        <location filename="../IOViewer.cpp" line="129"/>
        <location filename="../IOViewer.cpp" line="137"/>
        <location filename="../IOViewer.cpp" line="145"/>
        <location filename="../IOViewer.cpp" line="1364"/>
        <location filename="../IOViewer.cpp" line="1405"/>
        <source>Horizontal offset</source>
        <translation>Горизонтальное смещение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="125"/>
        <location filename="../IOViewer.cpp" line="133"/>
        <location filename="../IOViewer.cpp" line="141"/>
        <location filename="../IOViewer.cpp" line="149"/>
        <location filename="../IOViewer.cpp" line="1360"/>
        <location filename="../IOViewer.cpp" line="1401"/>
        <source>Vertical offset</source>
        <translation>Вертикальное смещение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="153"/>
        <location filename="../IOViewer.cpp" line="158"/>
        <location filename="../IOViewer.cpp" line="163"/>
        <location filename="../IOViewer.cpp" line="168"/>
        <location filename="../IOViewer.cpp" line="173"/>
        <location filename="../IOViewer.cpp" line="182"/>
        <location filename="../IOViewer.cpp" line="191"/>
        <location filename="../IOViewer.cpp" line="196"/>
        <location filename="../IOViewer.cpp" line="201"/>
        <location filename="../IOViewer.cpp" line="206"/>
        <location filename="../IOViewer.cpp" line="211"/>
        <location filename="../IOViewer.cpp" line="220"/>
        <source>Fractional part</source>
        <translation>Дробная часть</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="154"/>
        <location filename="../IOViewer.cpp" line="159"/>
        <location filename="../IOViewer.cpp" line="164"/>
        <location filename="../IOViewer.cpp" line="169"/>
        <location filename="../IOViewer.cpp" line="192"/>
        <location filename="../IOViewer.cpp" line="197"/>
        <location filename="../IOViewer.cpp" line="202"/>
        <location filename="../IOViewer.cpp" line="207"/>
        <source>Integer part</source>
        <translation>Целая часть</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="174"/>
        <location filename="../IOViewer.cpp" line="183"/>
        <location filename="../IOViewer.cpp" line="212"/>
        <location filename="../IOViewer.cpp" line="221"/>
        <source>Integer part (low)</source>
        <translation>Целая часть (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="178"/>
        <location filename="../IOViewer.cpp" line="187"/>
        <location filename="../IOViewer.cpp" line="216"/>
        <location filename="../IOViewer.cpp" line="225"/>
        <source>Integer part (high)</source>
        <translation>Целая часть (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="229"/>
        <location filename="../IOViewer.cpp" line="234"/>
        <source>End x</source>
        <translation>Конечный x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="230"/>
        <location filename="../IOViewer.cpp" line="235"/>
        <source>Start x</source>
        <translation>Начальный x</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="239"/>
        <location filename="../IOViewer.cpp" line="244"/>
        <source>End y</source>
        <translation>Конечный y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="240"/>
        <location filename="../IOViewer.cpp" line="245"/>
        <source>Start y</source>
        <translation>Начальный y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="249"/>
        <source>Window 0 enable BG 0</source>
        <translation>Окно 0 - включить BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="250"/>
        <source>Window 0 enable BG 1</source>
        <translation>Окно 0 - включить BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="251"/>
        <source>Window 0 enable BG 2</source>
        <translation>Окно 0 - включить BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="252"/>
        <source>Window 0 enable BG 3</source>
        <translation>Окно 0 - включить BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="253"/>
        <source>Window 0 enable OBJ</source>
        <translation>Окно 0 - включить OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="254"/>
        <source>Window 0 enable blend</source>
        <translation>Окно 0 - включить смешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="255"/>
        <source>Window 1 enable BG 0</source>
        <translation>Окно 1 - включить BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="256"/>
        <source>Window 1 enable BG 1</source>
        <translation>Окно 1 - включить BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="257"/>
        <source>Window 1 enable BG 2</source>
        <translation>Окно 1 - включить BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="258"/>
        <source>Window 1 enable BG 3</source>
        <translation>Окно 1 - включить BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="259"/>
        <source>Window 1 enable OBJ</source>
        <translation>Окно 1 - включить OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="260"/>
        <source>Window 1 enable blend</source>
        <translation>Окно 1 - включить смешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="264"/>
        <source>Outside window enable BG 0</source>
        <translation>Внешнее окно - включить BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="265"/>
        <source>Outside window enable BG 1</source>
        <translation>Внешнее окно - включить BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="266"/>
        <source>Outside window enable BG 2</source>
        <translation>Внешнее окно - включить BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="267"/>
        <source>Outside window enable BG 3</source>
        <translation>Внешнее окно - включить BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="268"/>
        <source>Outside window enable OBJ</source>
        <translation>Внешнее окно - включить OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="269"/>
        <source>Outside window enable blend</source>
        <translation>Внешнее окно - включить смешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="270"/>
        <source>OBJ window enable BG 0</source>
        <translation>Окно OBJ - включить BG 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="271"/>
        <source>OBJ window enable BG 1</source>
        <translation>Окно OBJ - включить BG 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="272"/>
        <source>OBJ window enable BG 2</source>
        <translation>Окно OBJ - включить BG 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="273"/>
        <source>OBJ window enable BG 3</source>
        <translation>Окно OBJ - включить BG 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="274"/>
        <source>OBJ window enable OBJ</source>
        <translation>Окно OBJ - включить OBJ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="275"/>
        <source>OBJ window enable blend</source>
        <translation>Окно OBJ - включить смешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="280"/>
        <source>Background mosaic size vertical</source>
        <translation>Фоновая мозаика - размер по вертикали</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="279"/>
        <source>Background mosaic size horizontal</source>
        <translation>Фоновая мозаика - размер по горизонтали</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="282"/>
        <source>Object mosaic size vertical</source>
        <translation>Мозаика объекта - размер по вертикали</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="281"/>
        <source>Object mosaic size horizontal</source>
        <translation>Мозаика объекта - размер по горизонтали</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="288"/>
        <source>BG 0 target 1</source>
        <translation>BG 0 цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="289"/>
        <source>BG 1 target 1</source>
        <translation>BG 1 цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="290"/>
        <source>BG 2 target 1</source>
        <translation>BG 2 цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="291"/>
        <source>BG 3 target 1</source>
        <translation>BG 3 цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="292"/>
        <source>OBJ target 1</source>
        <translation>OBJ цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="293"/>
        <source>Backdrop target 1</source>
        <translation>Фон цель 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="294"/>
        <source>Blend mode</source>
        <translation>Режим смешения</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="295"/>
        <source>Disabled</source>
        <translation>Выключен</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="296"/>
        <source>Additive blending</source>
        <translation>Аддитивное смешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="297"/>
        <source>Brighten</source>
        <translation>Увеличить яркость</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="298"/>
        <source>Darken</source>
        <translation>Уменьшить яркость</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="300"/>
        <source>BG 0 target 2</source>
        <translation>BG 0 цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="301"/>
        <source>BG 1 target 2</source>
        <translation>BG 1 цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="302"/>
        <source>BG 2 target 2</source>
        <translation>BG 2 цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="303"/>
        <source>BG 3 target 2</source>
        <translation>BG 3 цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="304"/>
        <source>OBJ target 2</source>
        <translation>OBJ цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="305"/>
        <source>Backdrop target 2</source>
        <translation>Фон цель 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="309"/>
        <source>Blend A (target 1)</source>
        <translation>Смешение A (цель 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="310"/>
        <source>Blend B (target 2)</source>
        <translation>Смешение B (цель 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="314"/>
        <source>Blend Y</source>
        <translation>Смешение Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="328"/>
        <location filename="../IOViewer.cpp" line="1099"/>
        <source>Sweep shifts</source>
        <translation>Сдвиги развёртки</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="329"/>
        <location filename="../IOViewer.cpp" line="1100"/>
        <source>Sweep subtract</source>
        <translation>Вычитание развёртки</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="330"/>
        <location filename="../IOViewer.cpp" line="1101"/>
        <source>Sweep time (in 1/128s)</source>
        <translation>Время развёртки (в 1/128 с)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="334"/>
        <location filename="../IOViewer.cpp" line="350"/>
        <location filename="../IOViewer.cpp" line="374"/>
        <location filename="../IOViewer.cpp" line="396"/>
        <location filename="../IOViewer.cpp" line="1105"/>
        <location filename="../IOViewer.cpp" line="1128"/>
        <location filename="../IOViewer.cpp" line="1153"/>
        <location filename="../IOViewer.cpp" line="1178"/>
        <source>Sound length</source>
        <translation>Длительность звука</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="335"/>
        <location filename="../IOViewer.cpp" line="351"/>
        <location filename="../IOViewer.cpp" line="1106"/>
        <location filename="../IOViewer.cpp" line="1129"/>
        <source>Duty cycle</source>
        <translation>Рабочий цикл</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="336"/>
        <location filename="../IOViewer.cpp" line="352"/>
        <location filename="../IOViewer.cpp" line="397"/>
        <location filename="../IOViewer.cpp" line="1110"/>
        <location filename="../IOViewer.cpp" line="1133"/>
        <location filename="../IOViewer.cpp" line="1182"/>
        <source>Envelope step time</source>
        <translation>Время шага огибающей</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="337"/>
        <location filename="../IOViewer.cpp" line="353"/>
        <location filename="../IOViewer.cpp" line="398"/>
        <location filename="../IOViewer.cpp" line="1111"/>
        <location filename="../IOViewer.cpp" line="1134"/>
        <location filename="../IOViewer.cpp" line="1183"/>
        <source>Envelope increase</source>
        <translation>Увеличение огибающей</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="338"/>
        <location filename="../IOViewer.cpp" line="354"/>
        <location filename="../IOViewer.cpp" line="399"/>
        <location filename="../IOViewer.cpp" line="1112"/>
        <location filename="../IOViewer.cpp" line="1135"/>
        <location filename="../IOViewer.cpp" line="1184"/>
        <source>Initial volume</source>
        <translation>Начальная громкость</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="342"/>
        <location filename="../IOViewer.cpp" line="360"/>
        <location filename="../IOViewer.cpp" line="388"/>
        <source>Sound frequency</source>
        <translation>Частота звука</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="343"/>
        <location filename="../IOViewer.cpp" line="361"/>
        <location filename="../IOViewer.cpp" line="389"/>
        <location filename="../IOViewer.cpp" line="411"/>
        <location filename="../IOViewer.cpp" line="1121"/>
        <location filename="../IOViewer.cpp" line="1144"/>
        <location filename="../IOViewer.cpp" line="1171"/>
        <location filename="../IOViewer.cpp" line="1197"/>
        <source>Timed</source>
        <translation>С привязкой по времени</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="344"/>
        <location filename="../IOViewer.cpp" line="362"/>
        <location filename="../IOViewer.cpp" line="390"/>
        <location filename="../IOViewer.cpp" line="412"/>
        <location filename="../IOViewer.cpp" line="1122"/>
        <location filename="../IOViewer.cpp" line="1145"/>
        <location filename="../IOViewer.cpp" line="1172"/>
        <location filename="../IOViewer.cpp" line="1198"/>
        <source>Reset</source>
        <translation>Сбросить</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="368"/>
        <source>Double-size wave table</source>
        <translation>Волновая таблица двойного размера</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="369"/>
        <source>Active wave table</source>
        <translation>Активная волновая таблица</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="370"/>
        <location filename="../IOViewer.cpp" line="1149"/>
        <source>Enable channel 3</source>
        <translation>Включить канал 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="375"/>
        <location filename="../IOViewer.cpp" line="1157"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="376"/>
        <location filename="../IOViewer.cpp" line="1158"/>
        <source>0%</source>
        <translation>0%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="377"/>
        <location filename="../IOViewer.cpp" line="434"/>
        <location filename="../IOViewer.cpp" line="1159"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="378"/>
        <location filename="../IOViewer.cpp" line="433"/>
        <location filename="../IOViewer.cpp" line="1160"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="379"/>
        <location filename="../IOViewer.cpp" line="432"/>
        <location filename="../IOViewer.cpp" line="1161"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="380"/>
        <location filename="../IOViewer.cpp" line="381"/>
        <location filename="../IOViewer.cpp" line="382"/>
        <location filename="../IOViewer.cpp" line="383"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="405"/>
        <location filename="../IOViewer.cpp" line="1188"/>
        <source>Clock divider</source>
        <translation>Знаменатель тактовой частоты</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="406"/>
        <location filename="../IOViewer.cpp" line="1189"/>
        <source>Register stages</source>
        <translation>Этапы регистра</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="407"/>
        <location filename="../IOViewer.cpp" line="1190"/>
        <source>15</source>
        <translation>15</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="408"/>
        <location filename="../IOViewer.cpp" line="1191"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="410"/>
        <location filename="../IOViewer.cpp" line="1193"/>
        <source>Shifter frequency</source>
        <translation>Частота шифтера</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="418"/>
        <source>PSG volume right</source>
        <translation>Громкость PSG (справа)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="419"/>
        <source>PSG volume left</source>
        <translation>Громкость PSG (слева)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="420"/>
        <location filename="../IOViewer.cpp" line="1209"/>
        <source>Enable channel 1 right</source>
        <translation>Включить канал 1 (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="421"/>
        <location filename="../IOViewer.cpp" line="1210"/>
        <source>Enable channel 2 right</source>
        <translation>Включить канал 2 (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="422"/>
        <location filename="../IOViewer.cpp" line="1211"/>
        <source>Enable channel 3 right</source>
        <translation>Включить канал 3 (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="423"/>
        <location filename="../IOViewer.cpp" line="1212"/>
        <source>Enable channel 4 right</source>
        <translation>Включить канал 4 (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="424"/>
        <location filename="../IOViewer.cpp" line="1213"/>
        <source>Enable channel 1 left</source>
        <translation>Включить канал 1 (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="425"/>
        <location filename="../IOViewer.cpp" line="1214"/>
        <source>Enable channel 2 left</source>
        <translation>Включить канал 2 (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="426"/>
        <location filename="../IOViewer.cpp" line="1215"/>
        <source>Enable channel 3 left</source>
        <translation>Включить канал 3 (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="427"/>
        <location filename="../IOViewer.cpp" line="1216"/>
        <source>Enable channel 4 left</source>
        <translation>Включить канал 4 (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="431"/>
        <source>PSG master volume</source>
        <translation>Общая громкость PSG</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="437"/>
        <source>Loud channel A</source>
        <translation>Громкий канал A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="438"/>
        <source>Loud channel B</source>
        <translation>Громкий канал B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="439"/>
        <source>Enable channel A right</source>
        <translation>Включить канал A (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="440"/>
        <source>Enable channel A left</source>
        <translation>Включить канал A (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="441"/>
        <source>Channel A timer</source>
        <translation>Таймер канала A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="442"/>
        <location filename="../IOViewer.cpp" line="449"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="443"/>
        <location filename="../IOViewer.cpp" line="450"/>
        <location filename="../IOViewer.cpp" line="779"/>
        <location filename="../IOViewer.cpp" line="794"/>
        <location filename="../IOViewer.cpp" line="810"/>
        <location filename="../IOViewer.cpp" line="826"/>
        <location filename="../IOViewer.cpp" line="992"/>
        <location filename="../IOViewer.cpp" line="1002"/>
        <location filename="../IOViewer.cpp" line="1012"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="445"/>
        <source>Channel A reset</source>
        <translation>Сброс канала A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="446"/>
        <source>Enable channel B right</source>
        <translation>Включить канал B (правый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="447"/>
        <source>Enable channel B left</source>
        <translation>Включить канал B (левый)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="448"/>
        <source>Channel B timer</source>
        <translation>Таймер канала B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="452"/>
        <source>Channel B reset</source>
        <translation>Сброс канала B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="456"/>
        <location filename="../IOViewer.cpp" line="1220"/>
        <source>Active channel 1</source>
        <translation>Активный канал 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="457"/>
        <location filename="../IOViewer.cpp" line="1221"/>
        <source>Active channel 2</source>
        <translation>Активный канал 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="458"/>
        <location filename="../IOViewer.cpp" line="1222"/>
        <source>Active channel 3</source>
        <translation>Активный канал 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="459"/>
        <location filename="../IOViewer.cpp" line="1223"/>
        <source>Active channel 4</source>
        <translation>Активный канал 4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="460"/>
        <location filename="../IOViewer.cpp" line="1224"/>
        <source>Enable audio</source>
        <translation>Включить звук</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="466"/>
        <source>Bias</source>
        <translation>DC-оффсет</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="467"/>
        <source>Resolution</source>
        <translation>Разрешение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="477"/>
        <location filename="../IOViewer.cpp" line="478"/>
        <location filename="../IOViewer.cpp" line="479"/>
        <location filename="../IOViewer.cpp" line="480"/>
        <location filename="../IOViewer.cpp" line="484"/>
        <location filename="../IOViewer.cpp" line="485"/>
        <location filename="../IOViewer.cpp" line="486"/>
        <location filename="../IOViewer.cpp" line="487"/>
        <location filename="../IOViewer.cpp" line="491"/>
        <location filename="../IOViewer.cpp" line="492"/>
        <location filename="../IOViewer.cpp" line="493"/>
        <location filename="../IOViewer.cpp" line="494"/>
        <location filename="../IOViewer.cpp" line="498"/>
        <location filename="../IOViewer.cpp" line="499"/>
        <location filename="../IOViewer.cpp" line="500"/>
        <location filename="../IOViewer.cpp" line="501"/>
        <location filename="../IOViewer.cpp" line="505"/>
        <location filename="../IOViewer.cpp" line="506"/>
        <location filename="../IOViewer.cpp" line="507"/>
        <location filename="../IOViewer.cpp" line="508"/>
        <location filename="../IOViewer.cpp" line="512"/>
        <location filename="../IOViewer.cpp" line="513"/>
        <location filename="../IOViewer.cpp" line="514"/>
        <location filename="../IOViewer.cpp" line="515"/>
        <location filename="../IOViewer.cpp" line="519"/>
        <location filename="../IOViewer.cpp" line="520"/>
        <location filename="../IOViewer.cpp" line="521"/>
        <location filename="../IOViewer.cpp" line="522"/>
        <location filename="../IOViewer.cpp" line="526"/>
        <location filename="../IOViewer.cpp" line="527"/>
        <location filename="../IOViewer.cpp" line="528"/>
        <location filename="../IOViewer.cpp" line="529"/>
        <location filename="../IOViewer.cpp" line="533"/>
        <location filename="../IOViewer.cpp" line="534"/>
        <location filename="../IOViewer.cpp" line="538"/>
        <location filename="../IOViewer.cpp" line="539"/>
        <location filename="../IOViewer.cpp" line="543"/>
        <location filename="../IOViewer.cpp" line="544"/>
        <location filename="../IOViewer.cpp" line="548"/>
        <location filename="../IOViewer.cpp" line="549"/>
        <location filename="../IOViewer.cpp" line="1246"/>
        <location filename="../IOViewer.cpp" line="1247"/>
        <location filename="../IOViewer.cpp" line="1251"/>
        <location filename="../IOViewer.cpp" line="1252"/>
        <location filename="../IOViewer.cpp" line="1256"/>
        <location filename="../IOViewer.cpp" line="1257"/>
        <location filename="../IOViewer.cpp" line="1261"/>
        <location filename="../IOViewer.cpp" line="1262"/>
        <location filename="../IOViewer.cpp" line="1266"/>
        <location filename="../IOViewer.cpp" line="1267"/>
        <location filename="../IOViewer.cpp" line="1271"/>
        <location filename="../IOViewer.cpp" line="1272"/>
        <location filename="../IOViewer.cpp" line="1276"/>
        <location filename="../IOViewer.cpp" line="1277"/>
        <location filename="../IOViewer.cpp" line="1281"/>
        <location filename="../IOViewer.cpp" line="1282"/>
        <location filename="../IOViewer.cpp" line="1286"/>
        <location filename="../IOViewer.cpp" line="1287"/>
        <location filename="../IOViewer.cpp" line="1291"/>
        <location filename="../IOViewer.cpp" line="1292"/>
        <location filename="../IOViewer.cpp" line="1296"/>
        <location filename="../IOViewer.cpp" line="1297"/>
        <location filename="../IOViewer.cpp" line="1301"/>
        <location filename="../IOViewer.cpp" line="1302"/>
        <location filename="../IOViewer.cpp" line="1306"/>
        <location filename="../IOViewer.cpp" line="1307"/>
        <location filename="../IOViewer.cpp" line="1311"/>
        <location filename="../IOViewer.cpp" line="1312"/>
        <location filename="../IOViewer.cpp" line="1316"/>
        <location filename="../IOViewer.cpp" line="1317"/>
        <location filename="../IOViewer.cpp" line="1321"/>
        <location filename="../IOViewer.cpp" line="1322"/>
        <source>Sample</source>
        <translation>Семпл</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="561"/>
        <location filename="../IOViewer.cpp" line="569"/>
        <location filename="../IOViewer.cpp" line="606"/>
        <location filename="../IOViewer.cpp" line="614"/>
        <location filename="../IOViewer.cpp" line="651"/>
        <location filename="../IOViewer.cpp" line="659"/>
        <location filename="../IOViewer.cpp" line="696"/>
        <location filename="../IOViewer.cpp" line="704"/>
        <source>Address (low)</source>
        <translation>Адрес (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="565"/>
        <location filename="../IOViewer.cpp" line="573"/>
        <location filename="../IOViewer.cpp" line="610"/>
        <location filename="../IOViewer.cpp" line="618"/>
        <location filename="../IOViewer.cpp" line="655"/>
        <location filename="../IOViewer.cpp" line="663"/>
        <location filename="../IOViewer.cpp" line="700"/>
        <location filename="../IOViewer.cpp" line="708"/>
        <source>Address (high)</source>
        <translation>Адрес (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1116"/>
        <location filename="../IOViewer.cpp" line="1139"/>
        <location filename="../IOViewer.cpp" line="1166"/>
        <source>Sound frequency (low)</source>
        <translation>Частота звука (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1120"/>
        <location filename="../IOViewer.cpp" line="1143"/>
        <location filename="../IOViewer.cpp" line="1170"/>
        <source>Sound frequency (high)</source>
        <translation>Частота звука (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1424"/>
        <source>Source (high)</source>
        <translation>Источник (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1428"/>
        <source>Source (low)</source>
        <translation>Источник (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1432"/>
        <source>Destination (high)</source>
        <translation>Цель (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1436"/>
        <source>Destination (low)</source>
        <translation>Цель (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1499"/>
        <location filename="../IOViewer.cpp" line="1511"/>
        <source>Green (low)</source>
        <translation>Зеленый (низкая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1500"/>
        <location filename="../IOViewer.cpp" line="1512"/>
        <source>Green (high)</source>
        <translation>Зеленый (высокая половина)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="577"/>
        <location filename="../IOViewer.cpp" line="622"/>
        <location filename="../IOViewer.cpp" line="667"/>
        <location filename="../IOViewer.cpp" line="712"/>
        <source>Word count</source>
        <translation>Количество слов</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="581"/>
        <location filename="../IOViewer.cpp" line="626"/>
        <location filename="../IOViewer.cpp" line="671"/>
        <location filename="../IOViewer.cpp" line="716"/>
        <source>Destination offset</source>
        <translation>Оффсет цели</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="582"/>
        <location filename="../IOViewer.cpp" line="588"/>
        <location filename="../IOViewer.cpp" line="627"/>
        <location filename="../IOViewer.cpp" line="633"/>
        <location filename="../IOViewer.cpp" line="672"/>
        <location filename="../IOViewer.cpp" line="678"/>
        <location filename="../IOViewer.cpp" line="717"/>
        <location filename="../IOViewer.cpp" line="723"/>
        <source>Increment</source>
        <translation>Увеличивать</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="583"/>
        <location filename="../IOViewer.cpp" line="589"/>
        <location filename="../IOViewer.cpp" line="628"/>
        <location filename="../IOViewer.cpp" line="634"/>
        <location filename="../IOViewer.cpp" line="673"/>
        <location filename="../IOViewer.cpp" line="679"/>
        <location filename="../IOViewer.cpp" line="718"/>
        <location filename="../IOViewer.cpp" line="724"/>
        <source>Decrement</source>
        <translation>Уменьшать</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="584"/>
        <location filename="../IOViewer.cpp" line="590"/>
        <location filename="../IOViewer.cpp" line="629"/>
        <location filename="../IOViewer.cpp" line="635"/>
        <location filename="../IOViewer.cpp" line="674"/>
        <location filename="../IOViewer.cpp" line="680"/>
        <location filename="../IOViewer.cpp" line="719"/>
        <location filename="../IOViewer.cpp" line="725"/>
        <source>Fixed</source>
        <translation>Не изменять</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="585"/>
        <location filename="../IOViewer.cpp" line="630"/>
        <location filename="../IOViewer.cpp" line="675"/>
        <location filename="../IOViewer.cpp" line="720"/>
        <source>Increment and reload</source>
        <translation>Увеличить и перезагрузить</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="587"/>
        <location filename="../IOViewer.cpp" line="632"/>
        <location filename="../IOViewer.cpp" line="677"/>
        <location filename="../IOViewer.cpp" line="722"/>
        <source>Source offset</source>
        <translation>Оффсет источника</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="593"/>
        <location filename="../IOViewer.cpp" line="638"/>
        <location filename="../IOViewer.cpp" line="683"/>
        <location filename="../IOViewer.cpp" line="729"/>
        <source>Repeat</source>
        <translation>Повторять</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="594"/>
        <location filename="../IOViewer.cpp" line="639"/>
        <location filename="../IOViewer.cpp" line="684"/>
        <location filename="../IOViewer.cpp" line="730"/>
        <source>32-bit</source>
        <translation>32 бита</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="595"/>
        <location filename="../IOViewer.cpp" line="640"/>
        <location filename="../IOViewer.cpp" line="685"/>
        <location filename="../IOViewer.cpp" line="731"/>
        <source>Start timing</source>
        <translation>Начать отсчёт времени</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="596"/>
        <location filename="../IOViewer.cpp" line="641"/>
        <location filename="../IOViewer.cpp" line="686"/>
        <location filename="../IOViewer.cpp" line="732"/>
        <location filename="../IOViewer.cpp" line="1442"/>
        <source>Immediate</source>
        <translation>Сразу</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="597"/>
        <location filename="../IOViewer.cpp" line="642"/>
        <location filename="../IOViewer.cpp" line="687"/>
        <location filename="../IOViewer.cpp" line="733"/>
        <location filename="../IOViewer.cpp" line="944"/>
        <location filename="../IOViewer.cpp" line="961"/>
        <location filename="../IOViewer.cpp" line="1091"/>
        <location filename="../IOViewer.cpp" line="1552"/>
        <source>VBlank</source>
        <translation>С VBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="598"/>
        <location filename="../IOViewer.cpp" line="643"/>
        <location filename="../IOViewer.cpp" line="688"/>
        <location filename="../IOViewer.cpp" line="734"/>
        <location filename="../IOViewer.cpp" line="945"/>
        <location filename="../IOViewer.cpp" line="962"/>
        <location filename="../IOViewer.cpp" line="1443"/>
        <source>HBlank</source>
        <translation>С HBlank</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="601"/>
        <location filename="../IOViewer.cpp" line="646"/>
        <location filename="../IOViewer.cpp" line="691"/>
        <location filename="../IOViewer.cpp" line="737"/>
        <location filename="../IOViewer.cpp" line="784"/>
        <location filename="../IOViewer.cpp" line="800"/>
        <location filename="../IOViewer.cpp" line="816"/>
        <location filename="../IOViewer.cpp" line="832"/>
        <location filename="../IOViewer.cpp" line="892"/>
        <source>IRQ</source>
        <translation>IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="602"/>
        <location filename="../IOViewer.cpp" line="647"/>
        <location filename="../IOViewer.cpp" line="692"/>
        <location filename="../IOViewer.cpp" line="738"/>
        <location filename="../IOViewer.cpp" line="785"/>
        <location filename="../IOViewer.cpp" line="801"/>
        <location filename="../IOViewer.cpp" line="817"/>
        <location filename="../IOViewer.cpp" line="833"/>
        <location filename="../IOViewer.cpp" line="1073"/>
        <location filename="../IOViewer.cpp" line="1450"/>
        <location filename="../IOViewer.cpp" line="1454"/>
        <source>Enable</source>
        <translation>Включить</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="644"/>
        <location filename="../IOViewer.cpp" line="689"/>
        <location filename="../IOViewer.cpp" line="735"/>
        <source>Audio FIFO</source>
        <translation>Аудио-буфер FIFO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="726"/>
        <source>Video Capture</source>
        <translation>Захват видео</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="728"/>
        <source>DRQ</source>
        <translation>DRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="774"/>
        <location filename="../IOViewer.cpp" line="789"/>
        <location filename="../IOViewer.cpp" line="805"/>
        <location filename="../IOViewer.cpp" line="821"/>
        <location filename="../IOViewer.cpp" line="1043"/>
        <location filename="../IOViewer.cpp" line="1055"/>
        <location filename="../IOViewer.cpp" line="1059"/>
        <location filename="../IOViewer.cpp" line="1063"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="778"/>
        <location filename="../IOViewer.cpp" line="793"/>
        <location filename="../IOViewer.cpp" line="809"/>
        <location filename="../IOViewer.cpp" line="825"/>
        <source>Scale</source>
        <translation>Шкала</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="780"/>
        <location filename="../IOViewer.cpp" line="795"/>
        <location filename="../IOViewer.cpp" line="811"/>
        <location filename="../IOViewer.cpp" line="827"/>
        <location filename="../IOViewer.cpp" line="1070"/>
        <source>1/64</source>
        <translation>1/64</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="781"/>
        <location filename="../IOViewer.cpp" line="796"/>
        <location filename="../IOViewer.cpp" line="812"/>
        <location filename="../IOViewer.cpp" line="828"/>
        <location filename="../IOViewer.cpp" line="1071"/>
        <source>1/256</source>
        <translation>1/256</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="782"/>
        <location filename="../IOViewer.cpp" line="797"/>
        <location filename="../IOViewer.cpp" line="813"/>
        <location filename="../IOViewer.cpp" line="829"/>
        <location filename="../IOViewer.cpp" line="1068"/>
        <source>1/1024</source>
        <translation>1/1024</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="799"/>
        <location filename="../IOViewer.cpp" line="815"/>
        <location filename="../IOViewer.cpp" line="831"/>
        <source>Cascade</source>
        <translation>Каскад</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="869"/>
        <location filename="../IOViewer.cpp" line="882"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="871"/>
        <location filename="../IOViewer.cpp" line="884"/>
        <source>Select</source>
        <translation>Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="872"/>
        <location filename="../IOViewer.cpp" line="885"/>
        <source>Start</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="873"/>
        <location filename="../IOViewer.cpp" line="886"/>
        <source>Right</source>
        <translation>Вправо</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="874"/>
        <location filename="../IOViewer.cpp" line="887"/>
        <source>Left</source>
        <translation>Влево</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="875"/>
        <location filename="../IOViewer.cpp" line="888"/>
        <source>Up</source>
        <translation>Вверх</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="876"/>
        <location filename="../IOViewer.cpp" line="889"/>
        <source>Down</source>
        <translation>Вниз</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="877"/>
        <location filename="../IOViewer.cpp" line="890"/>
        <source>R</source>
        <translation>R</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="878"/>
        <location filename="../IOViewer.cpp" line="891"/>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="893"/>
        <source>Condition</source>
        <translation>Условие</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="897"/>
        <source>SC</source>
        <translation>SC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="898"/>
        <source>SD</source>
        <translation>SD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="899"/>
        <source>SI</source>
        <translation>SI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="900"/>
        <source>SO</source>
        <translation>SO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="946"/>
        <location filename="../IOViewer.cpp" line="963"/>
        <source>VCounter</source>
        <translation>VCounter</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="947"/>
        <location filename="../IOViewer.cpp" line="964"/>
        <source>Timer 0</source>
        <translation>Таймер 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="948"/>
        <location filename="../IOViewer.cpp" line="965"/>
        <source>Timer 1</source>
        <translation>Таймер 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="949"/>
        <location filename="../IOViewer.cpp" line="966"/>
        <source>Timer 2</source>
        <translation>Таймер 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="950"/>
        <location filename="../IOViewer.cpp" line="967"/>
        <source>Timer 3</source>
        <translation>Таймер 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="951"/>
        <location filename="../IOViewer.cpp" line="968"/>
        <source>SIO</source>
        <translation>SIO</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="952"/>
        <location filename="../IOViewer.cpp" line="969"/>
        <source>DMA 0</source>
        <translation>DMA 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="953"/>
        <location filename="../IOViewer.cpp" line="970"/>
        <source>DMA 1</source>
        <translation>DMA 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="954"/>
        <location filename="../IOViewer.cpp" line="971"/>
        <source>DMA 2</source>
        <translation>DMA 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="955"/>
        <location filename="../IOViewer.cpp" line="972"/>
        <source>DMA 3</source>
        <translation>DMA 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="956"/>
        <location filename="../IOViewer.cpp" line="973"/>
        <source>Keypad</source>
        <translation>Клавиши</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="957"/>
        <location filename="../IOViewer.cpp" line="974"/>
        <source>Gamepak</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="978"/>
        <source>SRAM wait</source>
        <translation>Ожидание SRAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="979"/>
        <location filename="../IOViewer.cpp" line="985"/>
        <location filename="../IOViewer.cpp" line="995"/>
        <location filename="../IOViewer.cpp" line="1001"/>
        <location filename="../IOViewer.cpp" line="1005"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="980"/>
        <location filename="../IOViewer.cpp" line="986"/>
        <location filename="../IOViewer.cpp" line="996"/>
        <location filename="../IOViewer.cpp" line="1006"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="981"/>
        <location filename="../IOViewer.cpp" line="987"/>
        <location filename="../IOViewer.cpp" line="991"/>
        <location filename="../IOViewer.cpp" line="997"/>
        <location filename="../IOViewer.cpp" line="1007"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="982"/>
        <location filename="../IOViewer.cpp" line="988"/>
        <location filename="../IOViewer.cpp" line="998"/>
        <location filename="../IOViewer.cpp" line="1008"/>
        <location filename="../IOViewer.cpp" line="1011"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="984"/>
        <source>Cart 0 non-sequential</source>
        <translation>Картридж 0 (непоследовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="990"/>
        <source>Cart 0 sequential</source>
        <translation>Картридж 0 (последовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="994"/>
        <source>Cart 1 non-sequential</source>
        <translation>Картридж 1 (непоследовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1000"/>
        <source>Cart 1 sequential</source>
        <translation>Картридж 1 (последовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1004"/>
        <source>Cart 2 non-sequential</source>
        <translation>Картридж 2 (непоследовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1010"/>
        <source>Cart 2 sequential</source>
        <translation>Картридж 2 (последовательный)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1014"/>
        <source>PHI terminal</source>
        <translation>Терминал PHI</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1015"/>
        <location filename="../IOViewer.cpp" line="1451"/>
        <source>Disable</source>
        <translation>Отключить</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1016"/>
        <source>4.19MHz</source>
        <translation>4.19 МГц</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1017"/>
        <source>8.38MHz</source>
        <translation>8.38 МГц</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1018"/>
        <source>16.78MHz</source>
        <translation>16.78 МГц</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1020"/>
        <source>Gamepak prefetch</source>
        <translation>Предзагрузка Gamepak</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1026"/>
        <source>Enable IRQs</source>
        <translation>Включить IRQ</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1034"/>
        <source>Right/A</source>
        <translation>Вправо/A</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1035"/>
        <source>Left/B</source>
        <translation>Влево/B</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1036"/>
        <source>Up/Select</source>
        <translation>Вверх/Select</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1037"/>
        <source>Down/Start</source>
        <translation>Вниз/Start</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1038"/>
        <source>Active D-pad</source>
        <translation>Крестовина активна</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1039"/>
        <source>Active face buttons</source>
        <translation>Кнопки активны</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1047"/>
        <source>Internal clock</source>
        <translation>Внутренний тактовый генератор</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1048"/>
        <source>32× clocking (CGB only)</source>
        <translation>Тактовая частота 32× (только для CGB)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1049"/>
        <source>Transfer active</source>
        <translation>Активна передача данных</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1067"/>
        <source>Divider</source>
        <translation>Знаменатель</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1069"/>
        <source>1/16</source>
        <translation>1/16</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1092"/>
        <location filename="../IOViewer.cpp" line="1553"/>
        <source>LCD STAT</source>
        <translation>СТАТ. LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1093"/>
        <location filename="../IOViewer.cpp" line="1554"/>
        <source>Timer</source>
        <translation>Таймер</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1094"/>
        <location filename="../IOViewer.cpp" line="1555"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1095"/>
        <location filename="../IOViewer.cpp" line="1556"/>
        <source>Joypad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1202"/>
        <source>Volume right</source>
        <translation>Громкость (справа)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1203"/>
        <source>Output right</source>
        <translation>Вывод (справа)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1204"/>
        <source>Volume left</source>
        <translation>Громкость (слева)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1205"/>
        <source>Output left</source>
        <translation>Вывод (слева)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1326"/>
        <source>Background enable/priority</source>
        <translation>Вкл./приоритет фона</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1327"/>
        <source>Enable sprites</source>
        <translation>Включить спрайты</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1328"/>
        <source>Double-height sprites</source>
        <translation>Спрайты двойной высоты</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1329"/>
        <source>Background tile map</source>
        <translation>Карта тайлов фона</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1330"/>
        <location filename="../IOViewer.cpp" line="1339"/>
        <source>0x9800 – 0x9BFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1331"/>
        <location filename="../IOViewer.cpp" line="1340"/>
        <source>0x9C00 – 0x9FFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1333"/>
        <source>Background tile data</source>
        <translation>Данные тайлов фона</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1334"/>
        <source>0x8800 – 0x87FF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1335"/>
        <source>0x8000 – 0x8FFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1337"/>
        <source>Enable window</source>
        <translation>Включить окно</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1338"/>
        <source>Window tile map</source>
        <translation>Карта тайлов окна</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1342"/>
        <source>Enable LCD</source>
        <translation>Включить LCD</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1346"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1347"/>
        <source>0: HBlank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1348"/>
        <source>1: VBlank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1349"/>
        <source>2: OAM scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1350"/>
        <source>3: HDraw</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1352"/>
        <source>In LYC</source>
        <translation>В LYC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1353"/>
        <source>Enable HBlank (mode 0) IRQ</source>
        <translation>Включить IRQ HBlank (режим 0)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1354"/>
        <source>Enable VBlank (mode 1) IRQ</source>
        <translation>Включить IRQ VBlank (режим 1)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1355"/>
        <source>Enable OAM (mode 2) IRQ</source>
        <translation>Включить IRQ OAM (режим 2)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1356"/>
        <source>Enable LYC IRQ</source>
        <translation>Включить IRQ LYC</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1368"/>
        <source>Current Y coordinate</source>
        <translation>Текущая координата Y</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1372"/>
        <source>Comparison Y coordinate</source>
        <translation>Координата Y для сравнения</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1376"/>
        <source>Start upper byte</source>
        <translation>Начало (верхний байт)</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1380"/>
        <location filename="../IOViewer.cpp" line="1387"/>
        <location filename="../IOViewer.cpp" line="1394"/>
        <source>Color 0 shade</source>
        <translation>Оттенок цвета 0</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1381"/>
        <location filename="../IOViewer.cpp" line="1388"/>
        <location filename="../IOViewer.cpp" line="1395"/>
        <source>Color 1 shade</source>
        <translation>Оттенок цвета 1</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1382"/>
        <location filename="../IOViewer.cpp" line="1389"/>
        <location filename="../IOViewer.cpp" line="1396"/>
        <source>Color 2 shade</source>
        <translation>Оттенок цвета 2</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1383"/>
        <location filename="../IOViewer.cpp" line="1390"/>
        <location filename="../IOViewer.cpp" line="1397"/>
        <source>Color 3 shade</source>
        <translation>Оттенок цвета 3</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1411"/>
        <source>Prepare to switch speed</source>
        <translation>Приготовиться к изменению скорости</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1412"/>
        <source>Double speed</source>
        <translation>Двойная скорость</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1418"/>
        <source>VRAM bank</source>
        <translation>Банк VRAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1440"/>
        <source>Length</source>
        <translation>Длина</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1441"/>
        <source>Timing</source>
        <translation>Тайминг</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1448"/>
        <source>Write bit</source>
        <translation>Бит записи</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1449"/>
        <source>Read bit</source>
        <translation>Бит чтения</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1452"/>
        <location filename="../IOViewer.cpp" line="1453"/>
        <source>Unknown</source>
        <translation type="unfinished">Неизвестно</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1493"/>
        <location filename="../IOViewer.cpp" line="1505"/>
        <source>Current index</source>
        <translation>Текущий индекс</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1494"/>
        <location filename="../IOViewer.cpp" line="1506"/>
        <source>Auto-increment</source>
        <translation>Автоувеличение</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1498"/>
        <location filename="../IOViewer.cpp" line="1510"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1501"/>
        <location filename="../IOViewer.cpp" line="1513"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1517"/>
        <source>Sprite ordering</source>
        <translation>Порядок спрайтов</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1518"/>
        <source>OAM order</source>
        <translation>Порядок OAM</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1519"/>
        <source>x coordinate sorting</source>
        <translation>Сортировка x координат</translation>
    </message>
    <message>
        <location filename="../IOViewer.cpp" line="1530"/>
        <source>WRAM bank</source>
        <translation>Банк WRAM</translation>
    </message>
</context>
<context>
    <name>QGBA::InputController</name>
    <message>
        <location filename="../InputController.cpp" line="732"/>
        <location filename="../InputController.cpp" line="753"/>
        <source>Could not find a valid camera format!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../InputController.cpp" line="734"/>
        <source>Camera supported format: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::KeyEditor</name>
    <message>
        <location filename="../KeyEditor.cpp" line="45"/>
        <location filename="../KeyEditor.cpp" line="206"/>
        <source>---</source>
        <translation type="unfinished">---</translation>
    </message>
</context>
<context>
    <name>QGBA::LoadSaveState</name>
    <message>
        <location filename="../LoadSaveState.ui" line="14"/>
        <location filename="../LoadSaveState.ui" line="66"/>
        <source>%1 State</source>
        <translation>%1 состояние</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="41"/>
        <location filename="../LoadSaveState.ui" line="85"/>
        <location filename="../LoadSaveState.ui" line="107"/>
        <location filename="../LoadSaveState.ui" line="129"/>
        <location filename="../LoadSaveState.ui" line="151"/>
        <location filename="../LoadSaveState.ui" line="173"/>
        <location filename="../LoadSaveState.ui" line="195"/>
        <location filename="../LoadSaveState.ui" line="217"/>
        <location filename="../LoadSaveState.ui" line="239"/>
        <source>No Save</source>
        <translation>Нет сохранений</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="50"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="94"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="116"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="138"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="160"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="182"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="204"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="226"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="248"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.ui" line="261"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="75"/>
        <source>Load State</source>
        <translation>Загрузить состояние</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="75"/>
        <source>Save State</source>
        <translation>Сохранить состояние</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="184"/>
        <source>Empty</source>
        <translation>Пусто</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="193"/>
        <source>Corrupted</source>
        <translation>Повреждено</translation>
    </message>
    <message>
        <location filename="../LoadSaveState.cpp" line="228"/>
        <source>Slot %1</source>
        <translation>Слот %1</translation>
    </message>
</context>
<context>
    <name>QGBA::LogConfigModel</name>
    <message>
        <location filename="../LogConfigModel.cpp" line="90"/>
        <location filename="../LogConfigModel.cpp" line="111"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="92"/>
        <source>Fatal</source>
        <translation>Фатальная ошибка</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="94"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="96"/>
        <source>Warning</source>
        <translation type="unfinished">Внимание</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="98"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="100"/>
        <source>Debug</source>
        <translation type="unfinished">Откладка</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="102"/>
        <source>Stub</source>
        <translation type="unfinished">Заглушка</translation>
    </message>
    <message>
        <location filename="../LogConfigModel.cpp" line="104"/>
        <source>Game Error</source>
        <translation>Ошибка игры</translation>
    </message>
</context>
<context>
    <name>QGBA::LogController</name>
    <message>
        <location filename="../LogController.cpp" line="96"/>
        <source>[%1] %2: %3</source>
        <translation>[%1] %2: %3</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="107"/>
        <source>An error occurred</source>
        <translation>Произошла ошибка</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="179"/>
        <source>DEBUG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="181"/>
        <source>STUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="183"/>
        <source>INFO</source>
        <translation>ИНФОРМАЦИЯ</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="185"/>
        <source>WARN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="187"/>
        <source>ERROR</source>
        <translation>ОШИБКА</translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="189"/>
        <source>FATAL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../LogController.cpp" line="191"/>
        <source>GAME ERROR</source>
        <translation>ОШИБКА ИГРЫ</translation>
    </message>
</context>
<context>
    <name>QGBA::LogView</name>
    <message>
        <location filename="../LogView.ui" line="14"/>
        <source>Logs</source>
        <translation>Логи</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="22"/>
        <source>Enabled Levels</source>
        <translation>Активные уровни</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="28"/>
        <source>Debug</source>
        <translation>Откладка</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="38"/>
        <source>Stub</source>
        <translation>Заглушка</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="48"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="58"/>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="68"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="78"/>
        <source>Fatal</source>
        <translation>Фатальная ошибка</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="95"/>
        <source>Game Error</source>
        <translation>Ошибка игры</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="108"/>
        <source>Advanced settings</source>
        <translation>Расширенные настройки</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="128"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../LogView.ui" line="137"/>
        <source>Max Lines</source>
        <translation>Макс. строк</translation>
    </message>
</context>
<context>
    <name>QGBA::MapView</name>
    <message>
        <location filename="../MapView.ui" line="14"/>
        <source>Maps</source>
        <translation>Карты</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="43"/>
        <source>Magnification</source>
        <translation type="unfinished">Увеличить</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="124"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../MapView.ui" line="139"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="48"/>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="49"/>
        <location filename="../MapView.cpp" line="62"/>
        <source>Map base</source>
        <translation>Базовый адрес карты</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="50"/>
        <location filename="../MapView.cpp" line="63"/>
        <source>Tile base</source>
        <translation>Базовый адрес тайла</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="51"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="52"/>
        <location filename="../MapView.cpp" line="64"/>
        <source>Offset</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="53"/>
        <source>Xform</source>
        <translation>Xform</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="108"/>
        <source>Map Addr.</source>
        <translation>Адрес карты</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="109"/>
        <source>Mirror</source>
        <translation>Зеркально</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="146"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="148"/>
        <source>Both</source>
        <translation>Оба</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="150"/>
        <source>Horizontal</source>
        <translation>Горизонтально</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="152"/>
        <source>Vertical</source>
        <translation>Вертикально</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="183"/>
        <location filename="../MapView.cpp" line="184"/>
        <location filename="../MapView.cpp" line="239"/>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="282"/>
        <source>Export map</source>
        <translation>Экспорт карты</translation>
    </message>
    <message>
        <location filename="../MapView.cpp" line="283"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogController</name>
    <message>
        <location filename="../MemoryAccessLogController.cpp" line="117"/>
        <location filename="../MemoryAccessLogController.cpp" line="126"/>
        <source>Failed to open memory log file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogModel</name>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="67"/>
        <source>Data read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="69"/>
        <source>Data written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="71"/>
        <source>Code executed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="73"/>
        <source>Code aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="75"/>
        <source>8-bit access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="77"/>
        <source>16-bit access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="79"/>
        <source>32-bit access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="81"/>
        <source>64-bit access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="95"/>
        <source>Accessed by instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="97"/>
        <source>Accessed by DMA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="99"/>
        <source>Accessed by BIOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="101"/>
        <source>Compressed data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="103"/>
        <source>Accessed by memory copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="105"/>
        <source>(Unknown extra bit 5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="107"/>
        <source>(Unknown extra bit 6)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="109"/>
        <source>(Unknown extra bit 7)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="111"/>
        <source>Invalid instruction</source>
        <translation type="unfinished">Неверная инструкция</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="113"/>
        <source>Invalid read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="115"/>
        <source>Invalid write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="117"/>
        <source>Invalid executable address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="119"/>
        <source>(Private bit 0)</source>
        <translation type="unfinished">(Приватный бит 0)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="121"/>
        <source>(Private bit 1)</source>
        <translation type="unfinished">(Приватный бит 1)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="125"/>
        <source>ARM code</source>
        <translation type="unfinished">Код ARM</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="127"/>
        <source>Instruction opcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="129"/>
        <source>(Private bit 2)</source>
        <translation>(Приватный бит 2)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="134"/>
        <source>Thumb code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="136"/>
        <source>Instruction operand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="138"/>
        <source>(Private bit 3)</source>
        <translation>(Приватный бит 3)</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogModel.cpp" line="146"/>
        <source>(Unknown)</source>
        <translation type="unfinished">(Неизвестно)</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryAccessLogView</name>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="14"/>
        <source>Memory access logging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="23"/>
        <source>Log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="32"/>
        <source>Browse</source>
        <translation type="unfinished">Открыть</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="39"/>
        <source>Log additional information (uses 3× space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="46"/>
        <source>Load existing file if present</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="56"/>
        <source>Load</source>
        <translation type="unfinished">Загрузить</translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="66"/>
        <source>Unload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="76"/>
        <source>Regions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="87"/>
        <source>Export ROM snapshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="94"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.ui" line="104"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="96"/>
        <location filename="../MemoryAccessLogView.cpp" line="111"/>
        <source>Select access log file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryAccessLogView.cpp" line="96"/>
        <source>Memory access logs (*.mal)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryDump</name>
    <message>
        <location filename="../MemoryDump.ui" line="14"/>
        <source>Save Memory Range</source>
        <translation>Сохранить область памяти</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="20"/>
        <source>Start Address:</source>
        <translation>Исходный адрес:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="76"/>
        <source>Byte Count:</source>
        <translation>Количество байт:</translation>
    </message>
    <message>
        <location filename="../MemoryDump.ui" line="108"/>
        <source>Dump across banks within region</source>
        <comment>Generate dump with bytes all within the same region of memory, even if it crosses the bank boundary</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="24"/>
        <source>Save memory region</source>
        <translation>Сохранить область памяти</translation>
    </message>
    <message>
        <location filename="../MemoryDump.cpp" line="30"/>
        <source>Failed to open output file: %1</source>
        <translation>Не удалось открыть выходной файл: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryModel</name>
    <message>
        <location filename="../MemoryModel.cpp" line="45"/>
        <source>Copy selection</source>
        <translation>Копировать выделение</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="50"/>
        <source>Save selection</source>
        <translation>Сохранить выделение</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="55"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="60"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="118"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="168"/>
        <source>Load TBL</source>
        <translation>Загрузить TBL</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="222"/>
        <source>Save selected memory</source>
        <translation>Сохранение выделенной памяти</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="228"/>
        <source>Failed to open output file: %1</source>
        <translation>Не удалось открыть выходной файл: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="236"/>
        <source>Load memory</source>
        <translation>Загрузка памяти</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="242"/>
        <source>Failed to open input file: %1</source>
        <translation>Не удалось загрузить входной файл: %1</translation>
    </message>
    <message>
        <location filename="../MemoryModel.cpp" line="357"/>
        <source>ISO-8859-1</source>
        <translation>ISO-8859-1</translation>
    </message>
</context>
<context>
    <name>QGBA::MemorySearch</name>
    <message>
        <location filename="../MemorySearch.ui" line="26"/>
        <source>Memory Search</source>
        <translation>Поиск в памяти</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="51"/>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="56"/>
        <source>Current Value</source>
        <translation>Текущее значение</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="61"/>
        <location filename="../MemorySearch.ui" line="81"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="71"/>
        <source>Value</source>
        <translation>Значение</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="88"/>
        <source>Numeric</source>
        <translation>Число</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="101"/>
        <source>Text</source>
        <translation>Текст</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="118"/>
        <source>Width</source>
        <translation>Длина</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="125"/>
        <location filename="../MemorySearch.ui" line="185"/>
        <source>Guess</source>
        <translation>Догадка</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="138"/>
        <source>1 Byte (8-bit)</source>
        <translation>1 байт (8 бит)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="148"/>
        <source>2 Bytes (16-bit)</source>
        <translation>2 байта (16 бит)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="158"/>
        <source>4 Bytes (32-bit)</source>
        <translation>4 байта (32 бита)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="178"/>
        <source>Number type</source>
        <translation>Тип числа</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="195"/>
        <source>Decimal</source>
        <translation>10-ный</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="202"/>
        <source>Hexadecimal</source>
        <translation>16-ный</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="216"/>
        <source>Search type</source>
        <translation>Тип поиска</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="223"/>
        <source>Equal to value</source>
        <translation>Равно значению</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="236"/>
        <source>Greater than value</source>
        <translation>Больше значения</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="246"/>
        <source>Less than value</source>
        <translation>Меньше значения</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="256"/>
        <source>Unknown/changed</source>
        <translation>Неизвестно/изменилось</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="269"/>
        <source>Changed by value</source>
        <translation>Изменилось на значение</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="282"/>
        <source>Unchanged</source>
        <translation>Не изменилось</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="295"/>
        <source>Increased</source>
        <translation>Увеличилось</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="308"/>
        <source>Decreased</source>
        <translation>Уменьшилось</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="318"/>
        <source>Search ROM</source>
        <translation>Поиск в ROM</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="336"/>
        <source>New Search</source>
        <translation>Новый поиск</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="343"/>
        <source>Search Within</source>
        <translation>Поиск в результатах</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="350"/>
        <source>Open in Memory Viewer</source>
        <translation>Открыть в просмотре памяти</translation>
    </message>
    <message>
        <location filename="../MemorySearch.ui" line="357"/>
        <source>Refresh</source>
        <translation>Обновить</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="224"/>
        <source> (%0/%1×)</source>
        <translation> (%0/%1×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="226"/>
        <source> (⅟%0×)</source>
        <translation> (⅟%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="229"/>
        <source> (%0×)</source>
        <translation> (%0×)</translation>
    </message>
    <message>
        <location filename="../MemorySearch.cpp" line="233"/>
        <source>%1 byte%2</source>
        <translation>%1 байт%2</translation>
    </message>
</context>
<context>
    <name>QGBA::MemoryView</name>
    <message>
        <location filename="../MemoryView.ui" line="14"/>
        <source>Memory</source>
        <translation>Память</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="192"/>
        <source>String:</source>
        <translation>Строка:</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="205"/>
        <source>Load TBL</source>
        <translation>Загрузить TBL</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="233"/>
        <source>Copy Selection</source>
        <translation>Скопировать выделение</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="247"/>
        <source>Paste</source>
        <translation>Вставить</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="240"/>
        <source>Save Selection</source>
        <translation>Сохранить выделение</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="37"/>
        <source>Address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="106"/>
        <source>Alignment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="120"/>
        <source>1 Byte</source>
        <translation>1 Байт</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="125"/>
        <source>2 Bytes</source>
        <translation>2 Байта</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="130"/>
        <source>4 Bytes</source>
        <translation>4 Байта</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="152"/>
        <source>Signed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="172"/>
        <source>Unsigned:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="254"/>
        <source>Save Range</source>
        <translation>Сохранить область</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="267"/>
        <source>Load</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="282"/>
        <source>Selected address accesses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MemoryView.ui" line="304"/>
        <source>Logging configuration</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::MessagePainter</name>
    <message>
        <location filename="../MessagePainter.cpp" line="81"/>
        <source>Frame %1</source>
        <translation>Кадр %1</translation>
    </message>
</context>
<context>
    <name>QGBA::MultiplayerController</name>
    <message>
        <location filename="../MultiplayerController.cpp" line="313"/>
        <source>Couldn&apos;t find available save ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="367"/>
        <source>Trying to detach a multiplayer player that&apos;s not attached</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="407"/>
        <source>Clearing invalid save ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="416"/>
        <source>Clearing invalid preferred ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="437"/>
        <source>Trying to get player ID for a multiplayer player that&apos;s not attached</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MultiplayerController.cpp" line="451"/>
        <source>Trying to get save ID for a multiplayer player that&apos;s not attached</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::ObjView</name>
    <message>
        <location filename="../ObjView.ui" line="14"/>
        <source>Sprites</source>
        <translation>Спрайты</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="94"/>
        <source>Copy</source>
        <translation>Скопировать</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="137"/>
        <source>Geometry</source>
        <translation>Геометрия</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="145"/>
        <source>Position</source>
        <translation>Позиция</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="224"/>
        <source>Dimensions</source>
        <translation>Размеры</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="715"/>
        <source>Tile</source>
        <translation>Тайл</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="389"/>
        <source>Export</source>
        <translation>Экспорт</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="316"/>
        <source>Matrix</source>
        <translation>Матрица</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="402"/>
        <source>Attributes</source>
        <translation>Атрибуты</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="410"/>
        <source>Transform</source>
        <translation>Трансформация</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="430"/>
        <location filename="../ObjView.cpp" line="181"/>
        <source>Off</source>
        <translation>Выкл.</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="444"/>
        <source>Palette</source>
        <translation>Палитра</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="481"/>
        <source>Double Size</source>
        <translation>Двойной размер</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="548"/>
        <location filename="../ObjView.ui" line="561"/>
        <location filename="../ObjView.ui" line="632"/>
        <source>Return, Ctrl+R</source>
        <translation>Возврат, Ctrl+R</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="522"/>
        <source>Flipped</source>
        <translation>Поворот</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="545"/>
        <source>H</source>
        <extracomment>Short for horizontal</extracomment>
        <translation>Г</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="558"/>
        <source>V</source>
        <extracomment>Short for vertical</extracomment>
        <translation>В</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="572"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="592"/>
        <location filename="../ObjView.cpp" line="190"/>
        <source>Normal</source>
        <translation>Обычный</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="606"/>
        <source>Mosaic</source>
        <translation>Мозаика</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="643"/>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="677"/>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="72"/>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../ObjView.ui" line="122"/>
        <source>Magnification</source>
        <translation>Увеличить</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="160"/>
        <location filename="../ObjView.cpp" line="249"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="182"/>
        <location filename="../ObjView.cpp" line="183"/>
        <location filename="../ObjView.cpp" line="184"/>
        <location filename="../ObjView.cpp" line="185"/>
        <location filename="../ObjView.cpp" line="257"/>
        <location filename="../ObjView.cpp" line="258"/>
        <location filename="../ObjView.cpp" line="259"/>
        <location filename="../ObjView.cpp" line="260"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="193"/>
        <source>Trans</source>
        <translation>Прозрач.</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="196"/>
        <source>OBJWIN</source>
        <translation>OBJWIN</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="199"/>
        <source>Invalid</source>
        <translation>Неверно</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="256"/>
        <location filename="../ObjView.cpp" line="261"/>
        <source>N/A</source>
        <translation>Н/Д</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="287"/>
        <source>Export sprite</source>
        <translation>Экспорт спрайта</translation>
    </message>
    <message>
        <location filename="../ObjView.cpp" line="288"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::OverrideView</name>
    <message>
        <location filename="../OverrideView.ui" line="20"/>
        <source>Game Overrides</source>
        <translation>Переопределения игры</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="30"/>
        <source>Game Boy Advance</source>
        <translation>Game Boy Advance</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="42"/>
        <location filename="../OverrideView.ui" line="121"/>
        <location filename="../OverrideView.ui" line="241"/>
        <location filename="../OverrideView.ui" line="257"/>
        <source>Autodetect</source>
        <translation>Автоопределение</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="55"/>
        <source>Realtime clock</source>
        <translation>Реальное время</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="65"/>
        <source>Gyroscope</source>
        <translation>Гироскоп</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="75"/>
        <source>Tilt</source>
        <translation>Наклон</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="85"/>
        <source>Light sensor</source>
        <translation>Датчик света</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="95"/>
        <source>Rumble</source>
        <translation>Отдача</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="113"/>
        <source>Save type</source>
        <translation>Тип сохранения</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="126"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="131"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="136"/>
        <source>Flash 512kb</source>
        <translation>Flash 512kb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="141"/>
        <source>Flash 1Mb</source>
        <translation>Flash 1Mb</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="146"/>
        <source>EEPROM 8kB</source>
        <translation>EEPROM 8kB</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="151"/>
        <source>EEPROM 512 bytes</source>
        <translation>EEPROM 512 bytes</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="156"/>
        <source>SRAM 64kB (bootlegs only)</source>
        <translation>SRAM 64kB (только для бутлегов)</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="164"/>
        <source>Idle loop</source>
        <translation>Холостой цикл</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="190"/>
        <source>Game Boy Player features</source>
        <translation>Поддержка Game Boy Player</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="197"/>
        <source>VBA bug compatibility mode</source>
        <translation>Режим совместимости с багами VBA</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="227"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="233"/>
        <source>Game Boy model</source>
        <translation>Модель Game Boy</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="249"/>
        <source>Memory bank controller</source>
        <translation>Контроллер банка памяти</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="265"/>
        <source>Background Colors</source>
        <translation>Цвета фона</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="352"/>
        <source>Sprite Colors 1</source>
        <translation>Цвета спрайта 1</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="359"/>
        <source>Sprite Colors 2</source>
        <translation>Цвета спрайта 2</translation>
    </message>
    <message>
        <location filename="../OverrideView.ui" line="529"/>
        <source>Palette preset</source>
        <translation>Пресет палитры</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="67"/>
        <source>Official MBCs</source>
        <translation>Официальные MBC</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="71"/>
        <source>Licensed MBCs</source>
        <translation>Лицензионные MBC</translation>
    </message>
    <message>
        <location filename="../OverrideView.cpp" line="75"/>
        <source>Unlicensed MBCs</source>
        <translation>Нелицензионные MBC</translation>
    </message>
</context>
<context>
    <name>QGBA::PaletteView</name>
    <message>
        <location filename="../PaletteView.ui" line="14"/>
        <source>Palette</source>
        <translation>Палитра</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="44"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="94"/>
        <source>Objects</source>
        <translation>Объекты</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="153"/>
        <source>Selection</source>
        <translation>Выделение</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="184"/>
        <source>Red</source>
        <translation>Красный</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="191"/>
        <source>Green</source>
        <translation>Зеленый</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="198"/>
        <source>Blue</source>
        <translation>Синий</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="253"/>
        <source>16-bit value</source>
        <translation>16-битное значение</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="260"/>
        <source>Hex code</source>
        <translation>Hex-код</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="267"/>
        <source>Palette index</source>
        <translation>Индекс палитры</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="340"/>
        <source>Export BG</source>
        <translation>Экспорт BG</translation>
    </message>
    <message>
        <location filename="../PaletteView.ui" line="360"/>
        <source>Export OBJ</source>
        <translation>Экспорт OBJ</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="118"/>
        <source>#%0</source>
        <translation>#%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="119"/>
        <source>0x%0</source>
        <translation>0x%0</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="120"/>
        <location filename="../PaletteView.cpp" line="121"/>
        <location filename="../PaletteView.cpp" line="122"/>
        <location filename="../PaletteView.cpp" line="123"/>
        <source>0x%0 (%1)</source>
        <translation>0x%0 (%1)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="135"/>
        <source>Export palette</source>
        <translation>Экспорт палитры</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="136"/>
        <source>Windows PAL (*.pal);;Adobe Color Table (*.act)</source>
        <translation>Windows PAL (*.pal);;Adobe Color Table (*.act)</translation>
    </message>
    <message>
        <location filename="../PaletteView.cpp" line="142"/>
        <source>Failed to open output palette file: %1</source>
        <translation>Не удалось открыть файл палитры: %1</translation>
    </message>
</context>
<context>
    <name>QGBA::PlacementControl</name>
    <message>
        <location filename="../PlacementControl.ui" line="20"/>
        <source>Adjust placement</source>
        <translation>Настройка положения</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="26"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="65"/>
        <source>Offset</source>
        <translation>Смещение</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="72"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../PlacementControl.ui" line="79"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
</context>
<context>
    <name>QGBA::PrinterView</name>
    <message>
        <location filename="../PrinterView.ui" line="14"/>
        <source>Game Boy Printer</source>
        <translation>Принтер Game Boy</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="130"/>
        <source>Hurry up!</source>
        <translation>Поторопись!</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="137"/>
        <source>Tear off</source>
        <translation>Оторвать</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="223"/>
        <source>Copy</source>
        <translation>Копировать</translation>
    </message>
    <message>
        <location filename="../PrinterView.ui" line="180"/>
        <source>Magnification</source>
        <translation>Увеличение</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="59"/>
        <source>Save Printout</source>
        <translation>Сохранить распечатку</translation>
    </message>
    <message>
        <location filename="../PrinterView.cpp" line="59"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation type="unfinished">Portable Network Graphics (*.png)</translation>
    </message>
</context>
<context>
    <name>QGBA::ROMInfo</name>
    <message>
        <location filename="../ROMInfo.cpp" line="47"/>
        <location filename="../ROMInfo.cpp" line="61"/>
        <location filename="../ROMInfo.cpp" line="69"/>
        <location filename="../ROMInfo.cpp" line="77"/>
        <location filename="../ROMInfo.cpp" line="88"/>
        <location filename="../ROMInfo.cpp" line="101"/>
        <source>(unknown)</source>
        <translation>(неизвестно)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="56"/>
        <source> bytes</source>
        <translation> байт</translation>
    </message>
    <message>
        <location filename="../ROMInfo.cpp" line="91"/>
        <source>(no database present)</source>
        <translation>(нет в базе данных)</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="14"/>
        <source>ROM Info</source>
        <translation>Информация о ROM</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="23"/>
        <source>File information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="29"/>
        <source>Game name:</source>
        <translation>Название игры:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="83"/>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="100"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="134"/>
        <source>ROM header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="140"/>
        <source>Internal name:</source>
        <translation>Внутреннее наименование:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="157"/>
        <source>Game ID:</source>
        <translation>ID игры:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="174"/>
        <source>Maker Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="191"/>
        <source>Revision:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="49"/>
        <source>File size:</source>
        <translation>Размер файла:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="66"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../ROMInfo.ui" line="117"/>
        <source>Save file:</source>
        <translation>Файл сохранения:</translation>
    </message>
</context>
<context>
    <name>QGBA::ReportView</name>
    <message>
        <location filename="../ReportView.cpp" line="419"/>
        <source>Bug report archive</source>
        <translation>Архив отчётов об ошибках</translation>
    </message>
    <message>
        <location filename="../ReportView.cpp" line="419"/>
        <source>ZIP archive (*.zip)</source>
        <translation>ZIP архив (*.zip)</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="14"/>
        <source>Generate Bug Report</source>
        <translation>Создать отчёт об ошибке</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="67"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To file a bug report, please first generate a report file to attach to the bug report you&apos;re about to file. It is recommended that you include the save files, as these often help with debugging issues. This will collect some information about the version of {projectName} you&apos;re running, your configuration, your computer, and the game you currently have open (if any). Once this collection is completed you can review all of the information gathered below and save it to a zip file. The collection will automatically attempt to redact any personal information, such as your username if it&apos;s in any of the paths gathered, but just in case you can edit it afterwards. After you have generated and saved it, please click the button below or go to &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt; to file the bug report on GitHub. Make sure to attach the report you generated!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Чтобы отправить отчёт об ошибке, сначала создайте файл с отладочной информацией, который Вы приложите к отчету, который Вы собираетесь отправить. Рекомендуется также приложить все файлы сохранений, так как они часто могут помочь в отладке. Эта операция соберет информацию о запущенной версии {projectName}, Ваших конфигурации и компьютере, а также запущенной игре (если таковая имеется). Когда сбор закончится, Вы сможете проверить собранную информацию и сохранить её в zip-файл. Сборщик постарается автоматически удалить все личные данные, такие как имя пользователя, если оно присутствует в путях, но на всякий случай Вы можете вручную её исправить. После того, как Вы создали и сохранили файл с информацией, нажмите на кнопку ниже или посетите &lt;a href=&quot;https://mgba.io/i/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#2980b9;&quot;&gt;mgba.io/i&lt;/span&gt;&lt;/a&gt;, чтобы создать отчет об ошибке на GitHub. Убедитесь, что файл прикрепился!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="85"/>
        <source>Generate report</source>
        <translation>Создать отчет об ошибке</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="99"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="113"/>
        <source>Open issue list in browser</source>
        <translation>Открыть список текущих проблем в браузере</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="134"/>
        <source>Include save file</source>
        <translation>Включить файл сохранений</translation>
    </message>
    <message>
        <location filename="../ReportView.ui" line="150"/>
        <source>Create and include savestate</source>
        <translation>Создать сохранение состояния и включить его в отчет</translation>
    </message>
</context>
<context>
    <name>QGBA::SaveConverter</name>
    <message>
        <location filename="../SaveConverter.cpp" line="38"/>
        <source>Save games and save states (%1)</source>
        <translation>Игровые сохранения и сохранения состояний (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="39"/>
        <source>Select save game or save state</source>
        <translation>Выбор игрового сохранения или сохранения состояния</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="51"/>
        <source>Save games (%1)</source>
        <translation>Игровые сохранения (%1)</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="52"/>
        <source>Select save game</source>
        <translation>Выбор игрового сохранения</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="73"/>
        <source>Conversion failed</source>
        <translation>Ошибка конвертации</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="73"/>
        <source>Failed to convert the save game. This is probably a bug.</source>
        <translation>Не удалось сконвертировать игровое сохранение. Возможно, это баг.</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="89"/>
        <source>No file selected</source>
        <translation>Не выбран файл</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="96"/>
        <source>Could not open file</source>
        <translation>Не удалось открыть файл</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="111"/>
        <source>No valid formats found</source>
        <translation>Совместимые форматы не найдены</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="119"/>
        <source>Please select a valid input file</source>
        <translation>Пожалуйста, выберите совместимый входной файл</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="130"/>
        <source>No valid conversions found</source>
        <translation>Совместимые конверсии не найдены</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="659"/>
        <source>Cannot convert save games between platforms</source>
        <translation>Нельзя сконвертировать сохранения для разных платформ</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="14"/>
        <source>Convert/Extract Save Game</source>
        <translation>Конвертировать/извлечь сохранение</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="20"/>
        <source>Input file</source>
        <translation>Исходный файл</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="29"/>
        <location filename="../SaveConverter.ui" line="55"/>
        <source>Browse</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../SaveConverter.ui" line="46"/>
        <source>Output file</source>
        <translation>Выходной файл</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="454"/>
        <source>%1 %2 save game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="458"/>
        <source>little endian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="461"/>
        <source>big endian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="472"/>
        <source>SRAM</source>
        <translation>SRAM</translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="476"/>
        <source>%1 flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="480"/>
        <source>%1 EEPROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="486"/>
        <source> + RTC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="495"/>
        <source>%1 SRAM + RTC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="497"/>
        <source>%1 SRAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="502"/>
        <source>packed MBC2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="504"/>
        <source>unpacked MBC2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="509"/>
        <source>MBC6 flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="511"/>
        <source>MBC6 combined SRAM + flash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="513"/>
        <source>MBC6 SRAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="517"/>
        <source>TAMA5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="529"/>
        <source>%1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="533"/>
        <source>%1 save state with embedded %2 save game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="536"/>
        <source>%1 SharkPort %2 save game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SaveConverter.cpp" line="539"/>
        <source>%1 GameShark Advance SP %2 save game</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingController</name>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="279"/>
        <source>Lua scripts (*.lua)</source>
        <translation type="unfinished">Скрипты Lua (*.lua)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingController.cpp" line="281"/>
        <source>All files (*.*)</source>
        <translation type="unfinished">Все файлы (*.*)</translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingTextBuffer</name>
    <message>
        <location filename="../scripting/ScriptingTextBuffer.cpp" line="44"/>
        <source>Untitled buffer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QGBA::ScriptingView</name>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="14"/>
        <source>Scripting</source>
        <translation>Скрипты</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="71"/>
        <source>Run</source>
        <translation>Запустить</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="92"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="96"/>
        <source>Load recent script</source>
        <translation>Загрузить недавний скрипт</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="108"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="118"/>
        <source>Load script...</source>
        <translation>Загрузить скрипт...</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="123"/>
        <source>&amp;Load most recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="128"/>
        <source>&amp;Reset</source>
        <translation type="unfinished">Перезагрузить (&amp;R/&amp;К)</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="133"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="138"/>
        <source>Edit autorun scripts...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.ui" line="143"/>
        <source>Clear console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../scripting/ScriptingView.cpp" line="66"/>
        <source>Select script to load</source>
        <translation>Выбрать скрипт для загрузки</translation>
    </message>
</context>
<context>
    <name>QGBA::SensorView</name>
    <message>
        <location filename="../SensorView.ui" line="20"/>
        <source>Sensors</source>
        <translation>Датчики</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="31"/>
        <source>Realtime clock</source>
        <translation type="unfinished">Реальное время</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="50"/>
        <source>Fixed time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="37"/>
        <source>System time</source>
        <translation>Системное время</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="96"/>
        <source>Start time at</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="60"/>
        <source>Now</source>
        <translation>Сейчас</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="67"/>
        <source>Offset time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="80"/>
        <source> sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="126"/>
        <source>MM/dd/yy hh:mm:ss AP</source>
        <translation>ММ/дд/гг чч:мм:сс AP</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="136"/>
        <source>Light sensor</source>
        <translation type="unfinished">Датчик света</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="142"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="179"/>
        <source>Tilt sensor</source>
        <translation>Датчик наклона</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="187"/>
        <location filename="../SensorView.ui" line="276"/>
        <source>Set Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="197"/>
        <location filename="../SensorView.ui" line="286"/>
        <source>Set X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="268"/>
        <source>Gyroscope</source>
        <translation type="unfinished">Гироскоп</translation>
    </message>
    <message>
        <location filename="../SensorView.ui" line="296"/>
        <source>Sensitivity</source>
        <translation>Чувствительность</translation>
    </message>
</context>
<context>
    <name>QGBA::SettingsView</name>
    <message>
        <location filename="../SettingsView.cpp" line="157"/>
        <location filename="../SettingsView.cpp" line="232"/>
        <source>Qt Multimedia</source>
        <translation>Qt Multimedia</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="164"/>
        <source>SDL</source>
        <translation>SDL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="172"/>
        <source>Software (Qt)</source>
        <translation>Программный рендеринг (Qt)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1315"/>
        <location filename="../SettingsView.cpp" line="178"/>
        <source>OpenGL</source>
        <translation>OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="185"/>
        <source>OpenGL (force version 1.x)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="218"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="225"/>
        <source>None (Still Image)</source>
        <translation>Нет (статичное изображение)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="334"/>
        <source>Keyboard</source>
        <translation>Клавиатура</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="346"/>
        <source>Controllers</source>
        <translation>Контроллеры</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="411"/>
        <source>Shortcuts</source>
        <translation>Сочетания клавиш</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="414"/>
        <source>Shaders are not supported when the display driver is not OpenGL.

If it is set to OpenGL and you still see this, your graphics card or drivers may be too old.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="418"/>
        <location filename="../SettingsView.cpp" line="432"/>
        <location filename="../SettingsView.cpp" line="445"/>
        <location filename="../SettingsView.cpp" line="447"/>
        <source>Shaders</source>
        <translation>Шейдеры</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="468"/>
        <source>Select BIOS</source>
        <translation>Выбор BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="475"/>
        <source>Select directory</source>
        <translation>Выбор папки</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="483"/>
        <source>Select image</source>
        <translation type="unfinished">Выбор изображения</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="483"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation type="unfinished">Файл изображения (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="877"/>
        <source>(%1×%2)</source>
        <translation type="unfinished">(%1×%2)</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="895"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="900"/>
        <source>Just now</source>
        <translation>Только сейчас</translation>
    </message>
    <message>
        <location filename="../SettingsView.cpp" line="904"/>
        <source>Less than an hour ago</source>
        <translation>Менее часа назад</translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="909"/>
        <source>%n hour(s) ago</source>
        <translation>
            <numerusform>%n час назад</numerusform>
            <numerusform>%n часа назад</numerusform>
            <numerusform>%n часов назад</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../SettingsView.cpp" line="913"/>
        <source>%n day(s) ago</source>
        <translation>
            <numerusform>%n день назад</numerusform>
            <numerusform>%n дня назад</numerusform>
            <numerusform>%n дней назад</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="20"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="45"/>
        <source>Audio/Video</source>
        <translation>Аудио/Видео</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="50"/>
        <source>Gameplay</source>
        <translation>Игра</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="55"/>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="60"/>
        <source>Update</source>
        <translation>Обновления</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="65"/>
        <source>Emulation</source>
        <translation>Эмуляция</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="70"/>
        <source>Enhancements</source>
        <translation>Улучшения</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="75"/>
        <source>BIOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="80"/>
        <source>Paths</source>
        <translation>Пути</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="85"/>
        <source>Logging</source>
        <translation>Журналы</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="90"/>
        <source>Game Boy</source>
        <translation>Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="111"/>
        <source>Audio driver:</source>
        <translation>Аудиодрайвер:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="128"/>
        <source>Audio buffer:</source>
        <translation>Буфер аудио:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="140"/>
        <location filename="../SettingsView.ui" line="162"/>
        <source>1536</source>
        <translation type="unfinished">1536</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="147"/>
        <source>512</source>
        <translation type="unfinished">512</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="152"/>
        <source>768</source>
        <translation type="unfinished">768</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="157"/>
        <source>1024</source>
        <translation type="unfinished">1024</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="167"/>
        <source>2048</source>
        <translation type="unfinished">2048</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="172"/>
        <source>3072</source>
        <translation type="unfinished">3072</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="177"/>
        <source>4096</source>
        <translation type="unfinished">4096</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="185"/>
        <source>samples</source>
        <translation>семплов</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="194"/>
        <source>Sample rate:</source>
        <translation>Частота дискретизации:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="206"/>
        <location filename="../SettingsView.ui" line="223"/>
        <source>44100</source>
        <translation type="unfinished">44100</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="213"/>
        <source>22050</source>
        <translation type="unfinished">22050</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="218"/>
        <source>32000</source>
        <translation type="unfinished">32000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="228"/>
        <source>48000</source>
        <translation type="unfinished">48000</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="236"/>
        <source>Hz</source>
        <translation>Гц</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="245"/>
        <source>Volume:</source>
        <translation>Громкость:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="276"/>
        <location filename="../SettingsView.ui" line="316"/>
        <location filename="../SettingsView.ui" line="811"/>
        <location filename="../SettingsView.ui" line="836"/>
        <source>Mute</source>
        <translation>Без звука</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="285"/>
        <source>Fast forward volume:</source>
        <translation>Громкость при ускорении:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="325"/>
        <source>Audio in multiplayer:</source>
        <translation>Звук при мультиплеерной игре:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="332"/>
        <source>All windows</source>
        <translation>Из всех окон</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="345"/>
        <source>Player 1 window only</source>
        <translation>Только из окна 1 игрока</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="355"/>
        <source>Currently active player window</source>
        <translation>Из активного окна игрока</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="388"/>
        <source>Display driver:</source>
        <translation>Видеодрайвер:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="405"/>
        <source>Frameskip:</source>
        <translation>Пропуск кадров:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="414"/>
        <source>Skip every</source>
        <translation>Пропускать каждые</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="424"/>
        <location filename="../SettingsView.ui" line="1199"/>
        <source>frames</source>
        <translation>кадров</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="475"/>
        <source>FPS target:</source>
        <translation>Целевой FPS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="500"/>
        <source>frames per second</source>
        <translation>кадров/с</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="516"/>
        <source>Sync:</source>
        <translation>Синхронизировать:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="382"/>
        <location filename="../SettingsView.ui" line="525"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="105"/>
        <location filename="../SettingsView.ui" line="532"/>
        <source>Audio</source>
        <translation>Аудио</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="433"/>
        <source>Lock aspect ratio</source>
        <translation>Зафиксировать соотношение сторон</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="440"/>
        <source>Force integer scaling</source>
        <translation>Принудительное целочисленное масштабирование</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="454"/>
        <source>Bilinear filtering</source>
        <translation>Билинейная фильтрация</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="757"/>
        <source>Show filename instead of ROM name in library view</source>
        <translation>Показывать название файла вместо имени ROM в библиотеке</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="804"/>
        <location filename="../SettingsView.ui" line="829"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="795"/>
        <source>When inactive:</source>
        <translation>При неактивности:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="548"/>
        <source>On loading a game:</source>
        <translation>При загрузке игры:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="555"/>
        <source>Load last state</source>
        <translation>Загрузить последнее состояние</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="565"/>
        <source>Load cheats</source>
        <translation>Загрузить читы</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="575"/>
        <source>Edit autorun scripts</source>
        <translation>Редактировать скрипты автозапуска</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="599"/>
        <source>Save entered cheats</source>
        <translation>Сохранить введенные читы</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="820"/>
        <source>When minimized:</source>
        <translation>Когда окно свернуто:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="904"/>
        <source>Show frame count in OSD</source>
        <translation>Показывать количество кадров в OSD</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="911"/>
        <source>Show emulation info on reset</source>
        <translation>Показать инфо об эмуляции при перезагрузке</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="948"/>
        <source>Custom border:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="959"/>
        <source>Current channel:</source>
        <translation>Текущий канал:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="973"/>
        <source>Current version:</source>
        <translation>Текущая версия:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="997"/>
        <source>Update channel:</source>
        <translation>Канал обновлений:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1007"/>
        <source>Available version:</source>
        <translation>Доступная версия:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1014"/>
        <source>(Unknown)</source>
        <translation>(Неизвестно)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1024"/>
        <source>Last checked:</source>
        <translation>Последняя проверка:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1045"/>
        <source>Automatically check on start</source>
        <translation>Проверять при запуске</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1052"/>
        <source>Check now</source>
        <translation>Проверить</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1208"/>
        <source>Rewind speed:</source>
        <translation>Скорость перемотки:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1815"/>
        <source>Models</source>
        <translation>Модели</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1821"/>
        <source>GB only:</source>
        <translation>Только GB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1831"/>
        <source>SGB compatible:</source>
        <translation>Совместимость с SGB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1841"/>
        <source>GBC only:</source>
        <translation>Только GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1851"/>
        <source>GBC compatible:</source>
        <translation>Совместимость с GBC:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1861"/>
        <source>SGB and GBC compatible:</source>
        <translation>Совместимость с GBC и SGB:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1881"/>
        <source>Game Boy palette</source>
        <translation>Палитра Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2174"/>
        <source>Default color palette only</source>
        <translation>Только цветовая палитра по умолчанию</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2167"/>
        <source>SGB color palette if available</source>
        <translation>Цветовая палитра SGB (если доступна)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2181"/>
        <source>GBC color palette if available</source>
        <translation>Цветовая палитра GBC (если доступна)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2188"/>
        <source>SGB (preferred) or GBC color palette if available</source>
        <translation>Цветовая палитра SGB (предпочтительно) или GBC (если доступны)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2200"/>
        <source>Game Boy Camera</source>
        <translation>Game Boy Camera</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2206"/>
        <source>Driver:</source>
        <translation>Драйвер:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2223"/>
        <source>Source:</source>
        <translation>Источник:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="509"/>
        <source>Native (59.7275)</source>
        <translation>Родной (59.7275)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="447"/>
        <source>Interframe blending</source>
        <translation>Межкадровое смешение</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="589"/>
        <source>Periodically autosave state</source>
        <translation>Периодически сохранять состояние</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="709"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="726"/>
        <source>Library:</source>
        <translation>Библиотека:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="734"/>
        <source>List view</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="739"/>
        <source>Tree view</source>
        <translation>Дерево</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="747"/>
        <source>Show when no game open</source>
        <translation>Показывать, если игра не открыта</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="764"/>
        <source>Clear cache</source>
        <translation>Очистить кеш</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="778"/>
        <source>Allow opposing input directions</source>
        <translation>Допускать противоположные направления ввода</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="785"/>
        <source>Suspend screensaver</source>
        <translation>Выключить заставку</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="852"/>
        <source>Dynamically update window title</source>
        <translation>Динамически обновлять название окна</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="862"/>
        <source>Show FPS in title bar</source>
        <translation>Показывать FPS в заголовке окна</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="616"/>
        <source>Save state extra data:</source>
        <translation>Дополнительные данные сохранения состояния:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="633"/>
        <location filename="../SettingsView.ui" line="677"/>
        <source>Save game</source>
        <translation>Игровое сохранение</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="660"/>
        <source>Load state extra data:</source>
        <translation>Загружать из сохранения состояния:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1288"/>
        <source>Enable VBA bug compatibility in ROM hacks</source>
        <translation>Включить совместимость с VBA для ROM-хаков</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1887"/>
        <source>Preset:</source>
        <translation>Пресет:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="698"/>
        <source>Enable Discord Rich Presence</source>
        <translation type="unfinished">Вкл. расширенный статус в Discord</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="889"/>
        <source>Show OSD messages</source>
        <translation>Показывать сообщения в OSD</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="872"/>
        <source>Show filename instead of ROM name in title bar</source>
        <translation>Показывать имя файла вместо названия ROM в заголовке окна</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1066"/>
        <source>Fast forward speed:</source>
        <translation>Скорость перемотки (ускр.):</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1097"/>
        <location filename="../SettingsView.ui" line="1140"/>
        <source>Unbounded</source>
        <translation>Неограниченная</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1109"/>
        <source>Fast forward (held) speed:</source>
        <translation>Скорость перемотки (на удержании):</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1152"/>
        <source>Autofire interval:</source>
        <translation>Период автострельбы:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1176"/>
        <source>Enable rewind</source>
        <translation>Включить обратную перемотку</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1183"/>
        <source>Rewind history:</source>
        <translation>История обратной перемотки:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1245"/>
        <source>Idle loops:</source>
        <translation>Холостые циклы:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1253"/>
        <source>Run all</source>
        <translation>Выполнять все</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1258"/>
        <source>Remove known</source>
        <translation>Пропускать известные</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1263"/>
        <source>Detect and remove</source>
        <translation>Обнаруживать и удалять</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1271"/>
        <source>Preload entire ROM into memory</source>
        <translation>Загружать весь ROM в память заранее</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="623"/>
        <location filename="../SettingsView.ui" line="667"/>
        <source>Screenshot</source>
        <translation>Скриншот</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="643"/>
        <location filename="../SettingsView.ui" line="684"/>
        <source>Cheat codes</source>
        <translation>Читы</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1281"/>
        <source>Enable Game Boy Player features by default</source>
        <translation>Включить функции Game Boy Player по умолчанию</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1302"/>
        <source>Video renderer:</source>
        <translation>Рендерер видео:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1310"/>
        <source>Software</source>
        <translation>Программный</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1323"/>
        <source>OpenGL enhancements</source>
        <translation>Улучшения OpenGL</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1329"/>
        <source>High-resolution scale:</source>
        <translation>Масштаб высокого разрешения:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1367"/>
        <source>(240×160)</source>
        <translation>(240×160)</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1396"/>
        <source>GB BIOS file:</source>
        <translation>Файл GB BIOS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="932"/>
        <location filename="../SettingsView.ui" line="1415"/>
        <location filename="../SettingsView.ui" line="1443"/>
        <location filename="../SettingsView.ui" line="1471"/>
        <location filename="../SettingsView.ui" line="1499"/>
        <location filename="../SettingsView.ui" line="1557"/>
        <location filename="../SettingsView.ui" line="1605"/>
        <location filename="../SettingsView.ui" line="1653"/>
        <location filename="../SettingsView.ui" line="1701"/>
        <location filename="../SettingsView.ui" line="1749"/>
        <source>Browse</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1508"/>
        <source>Use BIOS file if found</source>
        <translation>Использовать файл BIOS, если найден</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1518"/>
        <source>Skip BIOS intro</source>
        <translation>Пропустить интро BIOS</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1480"/>
        <source>GBA BIOS file:</source>
        <translation>Файл GBA BIOS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1452"/>
        <source>GBC BIOS file:</source>
        <translation>Файл GBC BIOS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1424"/>
        <source>SGB BIOS file:</source>
        <translation>Файл SGB BIOS:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1532"/>
        <source>Save games</source>
        <translation>Сохранения</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1566"/>
        <location filename="../SettingsView.ui" line="1614"/>
        <location filename="../SettingsView.ui" line="1662"/>
        <location filename="../SettingsView.ui" line="1710"/>
        <location filename="../SettingsView.ui" line="1758"/>
        <source>Same directory as the ROM</source>
        <translation>Директория, в которой находится ROM</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1580"/>
        <source>Save states</source>
        <translation>Сохранения состояния</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1628"/>
        <source>Screenshots</source>
        <translation>Скриншоты</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1676"/>
        <source>Patches</source>
        <translation>Патчи</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1724"/>
        <source>Cheats</source>
        <translation type="unfinished">Читы</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1781"/>
        <source>Log to file</source>
        <translation>Сохранять журнал в файл</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1788"/>
        <source>Log to console</source>
        <translation>Выводить на консоль</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1802"/>
        <source>Select Log File</source>
        <translation>Выбрать файл журнала</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1897"/>
        <source>Default BG colors:</source>
        <translation>Цвета фона по умолчанию:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1871"/>
        <source>Super Game Boy borders</source>
        <translation>Рамки Super Game Boy</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="1984"/>
        <source>Default sprite colors 1:</source>
        <translation>1-е цвета по умолчанию для спрайта:</translation>
    </message>
    <message>
        <location filename="../SettingsView.ui" line="2071"/>
        <source>Default sprite colors 2:</source>
        <translation>2-е цвета по умолчанию для спрайта:</translation>
    </message>
</context>
<context>
    <name>QGBA::ShaderSelector</name>
    <message>
        <location filename="../ShaderSelector.cpp" line="77"/>
        <source>No shader active</source>
        <translation>Нет активных шейдеров</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="91"/>
        <location filename="../ShaderSelector.cpp" line="94"/>
        <source>Load shader</source>
        <translation>Загрузка шейдера</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="93"/>
        <source>mGBA Shaders</source>
        <translation>Шейдеры mGBA</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="124"/>
        <source>Error loading shader</source>
        <translation>Ошибка загрузки шейдера</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="124"/>
        <source>The shader &quot;%1&quot; could not be loaded successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="146"/>
        <source>No shader loaded</source>
        <translation>Нет загруженных шейдеров</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="154"/>
        <source>by %1</source>
        <translation>автор %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="165"/>
        <source>Preprocessing</source>
        <translation>Предобработка</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.cpp" line="172"/>
        <source>Pass %1</source>
        <translation>Проход %1</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="14"/>
        <source>Shaders</source>
        <translation type="unfinished">Шейдеры</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="28"/>
        <source>Active Shader:</source>
        <translation>Активный шейдер:</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="35"/>
        <source>Name</source>
        <translation type="unfinished">Имя</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="45"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="62"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="88"/>
        <source>Unload Shader</source>
        <translation>Выгрузить шейдер</translation>
    </message>
    <message>
        <location filename="../ShaderSelector.ui" line="95"/>
        <source>Load New Shader</source>
        <translation>Загрузить новый шейдер</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutModel</name>
    <message>
        <location filename="../ShortcutModel.cpp" line="67"/>
        <source>Action</source>
        <translation>Действие</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="69"/>
        <source>Keyboard</source>
        <translation>Клавиатура</translation>
    </message>
    <message>
        <location filename="../ShortcutModel.cpp" line="71"/>
        <source>Gamepad</source>
        <translation>Геймпад</translation>
    </message>
</context>
<context>
    <name>QGBA::ShortcutView</name>
    <message>
        <location filename="../ShortcutView.ui" line="14"/>
        <source>Edit Shortcuts</source>
        <translation>Редактировать сочетания клавиш</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="32"/>
        <source>Keyboard</source>
        <translation type="unfinished">Клавиатура</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="42"/>
        <source>Gamepad</source>
        <translation type="unfinished">Геймпад</translation>
    </message>
    <message>
        <location filename="../ShortcutView.ui" line="49"/>
        <source>Clear</source>
        <translation type="unfinished">Очистить</translation>
    </message>
</context>
<context>
    <name>QGBA::TileView</name>
    <message>
        <location filename="../TileView.cpp" line="226"/>
        <source>Export tiles</source>
        <translation>Экспорт тайлов</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="227"/>
        <location filename="../TileView.cpp" line="239"/>
        <source>Portable Network Graphics (*.png)</source>
        <translation>Portable Network Graphics (*.png)</translation>
    </message>
    <message>
        <location filename="../TileView.cpp" line="238"/>
        <source>Export tile</source>
        <translation>Экспорт тайла</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="14"/>
        <source>Tiles</source>
        <translation>Тайлы</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="170"/>
        <source>Export Selected</source>
        <translation>Экспортировать выбранное</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="184"/>
        <source>Export All</source>
        <translation>Экспортировать всё</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="40"/>
        <source>256 colors</source>
        <translation>256 цветов</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="33"/>
        <source>Palette</source>
        <translation type="unfinished">Палитра</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="73"/>
        <source>Magnification</source>
        <translation type="unfinished">Увеличить</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="96"/>
        <source>Tiles per row</source>
        <translation>Тайлов на строку</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="103"/>
        <source>Fit to window</source>
        <translation>Подогнать под размер окна</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="119"/>
        <source>Displayed tiles</source>
        <translation>Отображаемые тайлы</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="125"/>
        <source>Only BG tiles</source>
        <translation>Только тайлы BG</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="135"/>
        <source>Only OBJ tiles</source>
        <translation>Только тайлы OBJ</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="145"/>
        <source>Both</source>
        <translation type="unfinished">Оба</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="163"/>
        <source>Copy Selected</source>
        <translation>Скопировать выбранное</translation>
    </message>
    <message>
        <location filename="../TileView.ui" line="177"/>
        <source>Copy All</source>
        <translation>Скопировать всё</translation>
    </message>
</context>
<context>
    <name>QGBA::VideoView</name>
    <message>
        <location filename="../VideoView.cpp" line="226"/>
        <source>Failed to open output video file: %1</source>
        <translation>Не удалось открыть выходной видеофайл: %1</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="247"/>
        <source>Native (%0x%1)</source>
        <translation>Нативно (%0x%1)</translation>
    </message>
    <message>
        <location filename="../VideoView.cpp" line="262"/>
        <source>Select output file</source>
        <translation>Выбор выходного файла</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="20"/>
        <source>Record Video</source>
        <translation>Запись видео</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="40"/>
        <source>Start</source>
        <translation type="unfinished">Начать</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="56"/>
        <source>Stop</source>
        <translation type="unfinished">Остановить</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="69"/>
        <source>Select File</source>
        <translation type="unfinished">Выбрать файл</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="101"/>
        <source>Presets</source>
        <translation>Пресеты</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="109"/>
        <source>High &amp;Quality</source>
        <translation>Высокое качество (&amp;Q/&amp;Й)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="119"/>
        <source>&amp;YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="129"/>
        <source>WebM</source>
        <translation>WebM</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="146"/>
        <source>&amp;Lossless</source>
        <translation>Без потерь (&amp;L/&amp;Д)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="174"/>
        <source>&amp;1080p</source>
        <translation>&amp;1080p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="184"/>
        <source>&amp;720p</source>
        <translation>&amp;720p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="194"/>
        <source>&amp;480p</source>
        <translation>&amp;480p</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="207"/>
        <source>&amp;Native</source>
        <translation>Родной (&amp;N/&amp;Т)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="240"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="139"/>
        <source>MP4</source>
        <translation>MP4</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="167"/>
        <source>4K</source>
        <translation type="unfinished">4K</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="375"/>
        <source> Bitrate (kbps)</source>
        <translation> Битрейт (kbps)</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="420"/>
        <source>ABR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="465"/>
        <source>VBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="478"/>
        <source>CRF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="494"/>
        <source>Dimensions</source>
        <translation type="unfinished">Размеры</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="560"/>
        <source>Lock aspect ratio</source>
        <translation>Зафиксировать соотношение сторон</translation>
    </message>
    <message>
        <location filename="../VideoView.ui" line="575"/>
        <source>Show advanced</source>
        <translation>Расширенные настройки</translation>
    </message>
</context>
<context>
    <name>QGBA::Window</name>
    <message>
        <location filename="../Window.cpp" line="351"/>
        <source>Archives (%1)</source>
        <translation>Архивы (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="356"/>
        <location filename="../Window.cpp" line="372"/>
        <location filename="../Window.cpp" line="399"/>
        <source>Select ROM</source>
        <translation>Выбор игры</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="390"/>
        <source>Select folder</source>
        <translation>Выбор папки</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="534"/>
        <location filename="../Window.cpp" line="541"/>
        <source>Select save</source>
        <translation>Выбор сохранения</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="446"/>
        <source>Select patch</source>
        <translation>Выбор патча</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="446"/>
        <source>Patches (*.ips *.ups *.bps)</source>
        <translation>Патчи (*.ips *.ups *.bps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="457"/>
        <source>Select e-Reader dotcode</source>
        <translation>Выбор карточки e-Reader</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="457"/>
        <source>e-Reader card (*.raw *.bin *.bmp)</source>
        <translation>Карточка e-Reader (*.raw *.bin *.bmp)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="527"/>
        <source>Select image</source>
        <translation>Выбор изображения</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="527"/>
        <source>Image file (*.png *.gif *.jpg *.jpeg);;All files (*)</source>
        <translation>Файл изображения (*.png *.gif *.jpg *.jpeg);;All files (*)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="541"/>
        <source>GameShark saves (*.sps *.xps)</source>
        <translation>Сохранения GameShark (*.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="580"/>
        <source>Select video log</source>
        <translation>Выбор видеолога</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="580"/>
        <source>Video logs (*.mvl)</source>
        <translation>Видеологи (*.mvl)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1036"/>
        <source>Crash</source>
        <translation>Сбой</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1037"/>
        <source>The game has crashed with the following error:

%1</source>
        <translation>В игре произошёл сбой со следующей ошибкой:

%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1044"/>
        <source>Couldn&apos;t Start</source>
        <translation>Запуск не удался</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1045"/>
        <source>Could not start game.</source>
        <translation>Не удалось запустить игру.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1059"/>
        <source>Unimplemented BIOS call</source>
        <translation>Неизвестный вызов BIOS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1060"/>
        <source>This game uses a BIOS call that is not implemented. Please use the official BIOS for best experience.</source>
        <translation>Игра использует нереализованный вызов BIOS. Пожалуйста, воспользуйтесь официальным BIOS для лучшей совместимости.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1082"/>
        <source>Failed to create an appropriate display device, falling back to software display. Games may run slowly, especially with larger windows.</source>
        <translation>Не удалось создать устройство отображения, возврат к программному режиму. Игры могут идти медленнее, особенно в окнах больших размеров.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1180"/>
        <source>Really make portable?</source>
        <translation>Перейти в портативный режим?</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1181"/>
        <source>This will make the emulator load its configuration from the same directory as the executable. Do you want to continue?</source>
        <translation>После этого эмулятор будет загружать конфигурацию из папки с исполняемым файлом. Продолжить?</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1193"/>
        <source>Restart needed</source>
        <translation>Требуется перезапуск</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1194"/>
        <source>Some changes will not take effect until the emulator is restarted.</source>
        <translation>Для применения некоторых изменений требуется перезапустить эмулятор.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1245"/>
        <source> -  Player %1 of %2</source>
        <translation> -  Игрок %1 из %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1256"/>
        <source>%1 - %2</source>
        <translation>%1 - %2</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1258"/>
        <source>%1 - %2 - %3</source>
        <translation>%1 - %2 - %3</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1260"/>
        <source>%1 - %2 (%3 fps) - %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1324"/>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1326"/>
        <source>Load &amp;ROM...</source>
        <translation>Загрузить &amp;ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1329"/>
        <source>Load ROM in archive...</source>
        <translation>Загрузить игру из архива...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1330"/>
        <source>Add folder to library...</source>
        <translation>Добавить папку в библиотеку...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="407"/>
        <source>Save games (%1)</source>
        <translation type="unfinished">Игровые сохранения (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="408"/>
        <source>Select save game</source>
        <translation>Выбор игрового сохранения</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="416"/>
        <source>mGBA save state files (%1)</source>
        <translation>Файл сохранения состояния mGBA (%1)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="418"/>
        <location filename="../Window.cpp" line="423"/>
        <source>Select save state</source>
        <translation>Выбор сохранения состояния</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="465"/>
        <source>Select e-Reader card images</source>
        <translation>Выбор изображения карточки e-Reader</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="465"/>
        <source>Image file (*.png *.jpg *.jpeg)</source>
        <translation>Файл изображения (*.png *.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="466"/>
        <source>Conversion finished</source>
        <translation>Конвертация завершена</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="507"/>
        <source>%1 of %2 e-Reader cards converted successfully.</source>
        <translation>%1 из %2 карточек e-Reader успешно сконвертировано.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1334"/>
        <source>Load alternate save game...</source>
        <translation>Загрузить альтернативное сохранение...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1337"/>
        <source>Load temporary save game...</source>
        <translation>Загрузить временное сохранение...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1370"/>
        <source>Load &amp;patch...</source>
        <translation>Загрузить &amp;патч...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1373"/>
        <source>Boot BIOS</source>
        <translation>Загрузиться в BIOS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1467"/>
        <source>Replace ROM...</source>
        <translation>Заменить ROM...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1377"/>
        <source>Scan e-Reader dotcodes...</source>
        <translation>Сканировать dot-коды e-Reader...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1818"/>
        <source>Convert e-Reader card image to raw...</source>
        <translation>Конвертировать карту e-Reader в raw...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1381"/>
        <source>ROM &amp;info...</source>
        <translation>Информация об &amp;игре...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1383"/>
        <source>Recent</source>
        <translation>Недавние</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1783"/>
        <source>Make portable</source>
        <translation>Портативный режим</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1386"/>
        <source>&amp;Load state</source>
        <translation>&amp;Загрузить состояние</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1391"/>
        <source>Load state file...</source>
        <translation>Загрузить состояние из файла...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1396"/>
        <source>&amp;Save state</source>
        <translation>&amp;Сохранить состояние</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1401"/>
        <source>Save state file...</source>
        <translation>Сохранить состояние в файл...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1406"/>
        <source>Quick load</source>
        <translation>Быстрая загрузка</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1407"/>
        <source>Quick save</source>
        <translation>Быстрое сохранение</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1409"/>
        <source>Load recent</source>
        <translation>Загрузить недавнее</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1414"/>
        <source>Save recent</source>
        <translation>Сохранить в недавнее</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1422"/>
        <source>Undo load state</source>
        <translation>Отмена загрузки состояния</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1425"/>
        <source>Undo save state</source>
        <translation>Отмена сохранения состояния</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1432"/>
        <location filename="../Window.cpp" line="1437"/>
        <source>State &amp;%1</source>
        <translation>Слот &amp;%1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1563"/>
        <source>Load camera image...</source>
        <translation>Загрузить изображение с камеры...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1343"/>
        <source>Convert save game...</source>
        <translation>Конвертировать игровое сохранение...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="534"/>
        <source>GameShark saves (*.gsv *.sps *.xps)</source>
        <translation>Сохранения GameShark (*.gsv *.sps *.xps)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1155"/>
        <source>Failed to start audio processor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1205"/>
        <source>Reset needed</source>
        <translation>Необходима перезагрузка</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1206"/>
        <source>Some changes will not take effect until the game is reset.</source>
        <translation>Некоторые изменения не войдут в силу, пока игра не перезагружена.</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1333"/>
        <source>Save games</source>
        <translation>Сохранения</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1346"/>
        <source>Import GameShark Save...</source>
        <translation>Импорт сохранения GameShark...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1349"/>
        <source>Export GameShark Save...</source>
        <translation>Экспорт сохранения GameShark...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1356"/>
        <source>Automatically determine</source>
        <translation>Определить автоматически</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1360"/>
        <source>Use player %0 save game</source>
        <translation>Использовать сохранение игрока %0</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1444"/>
        <source>New multiplayer window</source>
        <translation>Новое окно мультиплеера</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1447"/>
        <source>Connect to Dolphin...</source>
        <translation>Соединение с Dolphin...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1453"/>
        <source>Report bug...</source>
        <translation>Сообщить об ошибке...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1459"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1460"/>
        <source>E&amp;xit</source>
        <translation>&amp;Выход</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1462"/>
        <source>&amp;Emulation</source>
        <translation>&amp;Эмуляция</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1463"/>
        <source>&amp;Reset</source>
        <translation>Перезагрузить (&amp;R/&amp;К)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1464"/>
        <source>Sh&amp;utdown</source>
        <translation>Выключить (&amp;U/&amp;Г)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1468"/>
        <source>Yank game pak</source>
        <translation>Пнуть картридж</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1471"/>
        <source>&amp;Pause</source>
        <translation>Пау&amp;за</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1480"/>
        <source>&amp;Next frame</source>
        <translation>Следующий кадр (&amp;N/&amp;Т)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1484"/>
        <source>Fast forward (held)</source>
        <translation>Перемотка (удержание)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1490"/>
        <source>&amp;Fast forward</source>
        <translation>Перемотк&amp;а</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1494"/>
        <source>Fast forward speed</source>
        <translation>Скорость перемотки</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1499"/>
        <source>Unbounded</source>
        <translation>Неограниченная</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1503"/>
        <source>%0x</source>
        <translation>%0x</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1507"/>
        <source>Increase fast forward speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1514"/>
        <source>Decrease fast forward speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1521"/>
        <source>Rewind (held)</source>
        <translation>Обратная перемотка (удержание)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1533"/>
        <source>Re&amp;wind</source>
        <translation>Обратная перемотка (&amp;W/&amp;Ц)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1538"/>
        <source>Step backwards</source>
        <translation>Шаг назад</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1545"/>
        <source>Solar sensor</source>
        <translation>Датчик солнца</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1546"/>
        <source>Increase solar level</source>
        <translation>Усилить солнечный свет</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1547"/>
        <source>Decrease solar level</source>
        <translation>Ослабить солнечный свет</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1548"/>
        <source>Brightest solar level</source>
        <translation>Ярчайшее солнце</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1551"/>
        <source>Darkest solar level</source>
        <translation>Тусклейшее солнце</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1557"/>
        <source>Brightness %1</source>
        <translation>Яркость %1</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1565"/>
        <source>Game Boy Printer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1574"/>
        <source>BattleChip Gate...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1578"/>
        <source>Audio/&amp;Video</source>
        <translation>Аудио/Видео (&amp;V/&amp;М)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1579"/>
        <source>Frame size</source>
        <translation>Размер кадра</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1581"/>
        <source>%1×</source>
        <translation>%1×</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1622"/>
        <source>Toggle fullscreen</source>
        <translation>Переключить полноэкранный режим</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1625"/>
        <source>&amp;Lock frame size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1638"/>
        <source>Lock aspect ratio</source>
        <translation>Зафиксировать соотношение сторон</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1650"/>
        <source>Force integer scaling</source>
        <translation>Принудительное целочисленное масштабирование</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1662"/>
        <source>Interframe blending</source>
        <translation>Межкадровое смешение</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1671"/>
        <source>Bilinear filtering</source>
        <translation>Билинейная фильтрация</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1679"/>
        <source>Frame&amp;skip</source>
        <translation>Пропуск кадров (&amp;S/&amp;Ы)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1692"/>
        <source>Mute</source>
        <translation>Выключить звук</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1699"/>
        <source>FPS target</source>
        <translation>Целевой FPS</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1707"/>
        <source>Native (59.7275)</source>
        <translation>Родной (59.7275)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1722"/>
        <source>Take &amp;screenshot</source>
        <translation>Снять скриншот (&amp;S/&amp;Ы)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1724"/>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1728"/>
        <source>Record A/V...</source>
        <translation>Записать аудио/видео...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1729"/>
        <source>Record GIF/WebP/APNG...</source>
        <translation>Записать GIF/WebP/APNG...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1733"/>
        <source>Video layers</source>
        <translation>Видеослои</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1734"/>
        <source>Audio channels</source>
        <translation>Аудиоканалы</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1736"/>
        <source>Adjust layer placement...</source>
        <translation>Настроить расположение слоёв...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1740"/>
        <source>Hide &amp;menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1745"/>
        <source>&amp;Tools</source>
        <translation>Инструм&amp;енты</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1746"/>
        <source>View &amp;logs...</source>
        <translation>Посмотреть в журнал... (&amp;L/&amp;Д)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1748"/>
        <source>Game &amp;overrides...</source>
        <translation>Переопределения для этой игры... (&amp;О/&amp;Щ)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1761"/>
        <source>Game Pak sensors...</source>
        <translation>Датчики в Game Pak...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1774"/>
        <source>&amp;Cheats...</source>
        <translation>Читы... (&amp;C/&amp;С)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1779"/>
        <source>Create forwarder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1782"/>
        <source>Settings...</source>
        <translation>Настройки...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1787"/>
        <source>Open debugger console...</source>
        <translation>Открыть консоль отладки...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1789"/>
        <source>Start &amp;GDB server...</source>
        <translation>Запустить сервер &amp;GDB...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1776"/>
        <source>Scripting...</source>
        <translation>Скрипты...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1797"/>
        <source>Game state views</source>
        <translation>Просмотр состояния игры</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1798"/>
        <source>View &amp;palette...</source>
        <translation>Просмотр палитры... (&amp;P/&amp;З)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1799"/>
        <source>View &amp;sprites...</source>
        <translation>Просмотр спрайтов... (&amp;S/&amp;Ы)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1800"/>
        <source>View &amp;tiles...</source>
        <translation>Просмотр тайлов... (&amp;T/&amp;Е)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1801"/>
        <source>View &amp;map...</source>
        <translation>Просмотр карты... (&amp;M/&amp;Ь)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1802"/>
        <source>&amp;Frame inspector...</source>
        <translation>Изучение фрейм&amp;а...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1803"/>
        <source>View memory...</source>
        <translation>Просмотр памяти...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1804"/>
        <source>Search memory...</source>
        <translation>Поиск в памяти...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1805"/>
        <source>View &amp;I/O registers...</source>
        <translation>Просмотр регистров &amp;I/O...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1808"/>
        <source>Log memory &amp;accesses...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1822"/>
        <source>Record debug video log...</source>
        <translation>Запись отладочного видеожурнала...</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1823"/>
        <source>Stop debug video log</source>
        <translation>Закончить запись отладочного видеожурнала</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1827"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из полноэкранного режима</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1829"/>
        <source>GameShark Button (held)</source>
        <translation>Кнопка GameShark (удерживается)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1835"/>
        <source>Autofire</source>
        <translation>Автострельба</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1836"/>
        <source>Autofire A</source>
        <translation>A (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1841"/>
        <source>Autofire B</source>
        <translation>B (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1846"/>
        <source>Autofire L</source>
        <translation>L (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1851"/>
        <source>Autofire R</source>
        <translation>R (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1856"/>
        <source>Autofire Start</source>
        <translation>Start (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1861"/>
        <source>Autofire Select</source>
        <translation>Select (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1866"/>
        <source>Autofire Up</source>
        <translation>Вверх (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1871"/>
        <source>Autofire Right</source>
        <translation>Вправо (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1876"/>
        <source>Autofire Down</source>
        <translation>Вниз (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="1881"/>
        <source>Autofire Left</source>
        <translation>Влево (автострельба)</translation>
    </message>
    <message>
        <location filename="../Window.cpp" line="2086"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../utils.cpp" line="26"/>
        <source>%1 byte</source>
        <translation>%1 байт</translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="29"/>
        <source>%1 kiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="33"/>
        <source>%1 MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="183"/>
        <source>Super (L)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="185"/>
        <source>Super (R)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="187"/>
        <source>Menu</source>
        <translation type="unfinished">Меню</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../utils.cpp" line="174"/>
        <source>Shift</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="176"/>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="178"/>
        <source>Alt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../utils.cpp" line="180"/>
        <source>Meta</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
