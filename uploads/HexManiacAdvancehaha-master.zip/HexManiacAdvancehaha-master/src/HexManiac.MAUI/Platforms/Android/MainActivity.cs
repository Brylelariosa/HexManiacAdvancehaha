using Android.App;
using Android.Content.PM;
using Microsoft.Maui;

namespace HavenSoft.HexManiac.MAUI.Platforms.Android {
   [Activity(
      Theme = "@style/Maui.SplashTheme",
      MainLauncher = true,
      ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode
         | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density)]
   public class MainActivity : MauiAppCompatActivity { }
}
